from django.urls import path
from razorpayment.views import *
from .api_view import razorpay_api_payment

app_name = "razorpayment"

urlpatterns = [
    path("razor_api/", payment_home_api, name="razor_payment"),
    path("success/", payment_success, name="payment_success"),
    path("api/", razorpay_api_payment, name="razorpay_api_payment"),
    path('get-csrf-token/', get_csrf_token, name='get_csrf_token'),
]

