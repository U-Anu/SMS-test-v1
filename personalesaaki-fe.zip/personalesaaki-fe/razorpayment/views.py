from django.shortcuts import render, redirect
from django.conf import settings
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from .forms import PaymentForm
from paymentgateway.models import *
import razorpay


# Initialize Razorpay client
client = razorpay.Client(
    auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET_KEY)
)
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def payment_home_api(request):
    print("Razorpay Payment Home")
    form = PaymentForm()
    if request.method == "POST":
        print("Processing Razorpay Payment post")
        form = PaymentForm(request.POST)
        if form.is_valid():
            print("Processing Razorpay Payment valid form")
            name = form.cleaned_data["name"]
            email = form.cleaned_data["email"]
            phone_no = form.cleaned_data["phone_no"]
            amount = form.cleaned_data["amount"]
            return_url = form.cleaned_data["return_url"]
            source = form.cleaned_data["source"]
            order_amount = int(amount * 100)  # convert to paisa
            order_currency = "INR"
            # Create Razorpay order
            order = client.order.create(
                dict(amount=order_amount, currency=order_currency, payment_capture=1))
            # Save initial payment detail (PENDING)
            print("Creating PaymentDetail entry",order)
            payment_gateway = PaymentGateway.objects.get(name="Razorpay")  # adjust name if needed
            print("Payment Gateway fetched:",payment_gateway)
            PaymentDetail.objects.create(
                payment_order_id=order["id"],
                amount=amount,
                payment_mode="OTHER",  # will update later after callback
                status="PENDING",
                created_time=timezone.now(),
                payment_gateway=payment_gateway,)
            PaymentLog.objects.create(
                name=name,
                email=email,
                channel_id=order["id"],
                amount=amount,
                source=source,)
            print("Rendering Razorpay Payment Form with context")
            context = {
                "form": form,
                "api_key": settings.RAZORPAY_API_KEY,
                "order_id": order["id"],
                "amount": order_amount,
                "name": name,
                "email": email,
                "phone_no": phone_no,
                "return_url": return_url,}
            print("Context prepared:",context)
            return render(request, "payment/razorpay_api.html", context)
    print("Rendering Razorpay Payment Form")
    return render(request, "payment/razorpay_api.html", {"form": form})



@csrf_exempt
def payment_success(request):
    """Handle payment success callback"""
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone_no = request.POST.get("phone_no")
        amount = request.POST.get("amount")
        order_id = request.POST.get("razorpay_order_id")
        payment_id = request.POST.get("razorpay_payment_id")
        payment_mode = "UPI"
        # Update PaymentDetail status
        try:
            payment = PaymentDetail.objects.get(payment_order_id=order_id)
            payment.status = "SUCCESS"
            payment.payment_mode = payment_mode
            payment.updated_at = timezone.now()
            payment.save()
        except PaymentDetail.DoesNotExist:
            # In case something went wrong or user skipped page
            payment_gateway = PaymentGateway.objects.get(name="Razorpay")
            PaymentDetail.objects.create(
                payment_order_id=order_id,
                amount=amount,
                payment_mode=payment_mode,
                status="SUCCESS",
                created_time=timezone.now(),
                payment_gateway=payment_gateway,)
        return render(
            request,
            "success.html",
            {
                "name": name,
                "email": email,
                "phone_no": phone_no,
                "amount": amount,
                "payment_id": payment_id,
            },
        )
    print("payment success")
    return render(request, "payment/success.html")


# =============
# views.py
from django.http import JsonResponse
from django.middleware.csrf import get_token
from django.views.decorators.csrf import ensure_csrf_cookie

@ensure_csrf_cookie
def get_csrf_token(request):
    """
    Sets csrftoken cookie (ensure_csrf_cookie) and returns token in JSON.
    Call this from frontend before POSTing.
    """
    token = get_token(request)
    return JsonResponse({'csrftoken': token})

# ================