from django import forms

class PaymentForm(forms.Form):

    name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your name'
        })
    )

    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your email'
        })
    )

    phone_no = forms.CharField(
        max_length=15,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your phone number'
        })
    )

    # HIDDEN INPUT: return_url
    return_url = forms.CharField(
        max_length=255,
        widget=forms.HiddenInput()
    )

    # HIDDEN INPUT: source
    source = forms.CharField(
        max_length=100,
        widget=forms.HiddenInput()
    )

    # READONLY INPUT: amount
    amount = forms.IntegerField(
        min_value=1,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'readonly': 'readonly'
        })
    )
