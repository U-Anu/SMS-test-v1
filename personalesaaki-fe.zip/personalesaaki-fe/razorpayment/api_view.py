from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from django.conf import settings
import uuid
import razorpay
from paymentgateway.models import PaymentDetail, PaymentGateway
from .serializers import RazorpayPaymentSerializer


client = razorpay.Client(
    auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET_KEY)
)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def razorpay_api_payment(request):
    serializer = RazorpayPaymentSerializer(data=request.data)
    if serializer.is_valid():
        name = serializer.validated_data["name"]
        email = serializer.validated_data["email"]
        phone_no = serializer.validated_data["phone_no"]
        amount = serializer.validated_data["amount"]

        amount_int = int(float(amount) * 100)

        order = client.order.create(
            dict(amount=amount_int, currency="INR", payment_capture=1)
        )

        payment_order_id = str(uuid.uuid4())[:8].upper()
        razorpay_gateway, _ = PaymentGateway.objects.get_or_create(name="Razorpay")

        PaymentDetail.objects.create(
            payment_order_id=order["id"],
            amount=amount,
            payment_mode="OTHER",
            status="PENDING",
            payment_gateway=razorpay_gateway,
            created_time=timezone.now(),
        )

        return Response(
            {
                "success": True,
                "name": name,
                "email": email,
                "phone_no": phone_no,
                "amount": amount,
                "razorpay_order_id": order["id"],
                # "payment_order_id": payment_order_id,
                # "api_key": settings.RAZORPAY_API_KEY,
            },
            status=status.HTTP_200_OK,
        )
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
