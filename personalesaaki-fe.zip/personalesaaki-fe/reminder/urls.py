from django.urls import path,include
from .views import *
urlpatterns = [
    
	path("financialreminder/", financialreminder, name="financialreminder"),
	path("notifications/", notifications, name="notifications"),
	path("voice/", voice, name="voice"),
	path("notify_delete/<pk>/", notify_delete, name="notify_delete"),
	path("res_pay/<id>/", res_pay, name="res_pay"),
	# path("TransFinancial/<id>/", TransFinancial, name="TransFinancial"),
 	path("transaction_financial_reminder/<id>/", TransFinancial, name="transaction_financial_reminder"),
	path("reminder_notify/<id>/", financialreminder_notify_res, name="financialreminder_notify_res"),
	path("reminder_notify_exp/<id>/", financialreminder_notify_exp, name="financialreminder_notify_exp"),
	path("change_status/<id>/", change_status, name="change_status"),
	path("financialreminder_pay/", financialreminder_pay, name="financialreminder_pay"),
	path("financialreminder_edit/<pk>/", financialreminder_edit, name="financialreminder_edit"),
	path("financialreminder_delete/<pk>/", financialreminder_delete, name="financialreminder_delete"),
	path("raszor/", reszor, name="raszor"),
	path("specific_rem/", specific_rem, name="specific_rem"),
]