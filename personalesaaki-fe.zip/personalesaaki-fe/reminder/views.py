from django.http import JsonResponse
from django.shortcuts import render, redirect
from .forms import *
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.forms import formset_factory
from django.forms import modelformset_factory
from mainapp.views import *
from django.template.loader import render_to_string

APP_NAME = __name__.split('.')[0]

BASEURL = settings.BASEURL


# create and view table function
@custom_login_required
def financialreminder(request):
    try:
        token = request.session['user_token']


        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
    

        form=FinancialReminderForm()
        endpoint = 'reminder/financialreminder/'
        if request.method=="POST":
            form=FinancialReminderForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('financialreminder')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('financialreminder_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'financialreminder.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records
        }
        return render(request,'financialreminder.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# create and view table function
@custom_login_required
def financialreminder_notify_res(request,id):
    print("notify id",id)
    try:
        token = request.session['user_token']


        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
    

        form=FinancialReminder_resForm()
        endpoint = 'reminder/financialreminder/'
        if request.method=="POST":
            form=FinancialReminder_resForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                Output['notify']=id
                Output['reminder_type']='receivables'
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('financialreminder')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('financialreminder_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'fin_res.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records
        }
        return render(request,'fin_res.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# create and view table function
@custom_login_required
def financialreminder_notify_exp(request,id):
    print("notify id",id)
    try:
        token = request.session['user_token']


        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
    

        form=FinancialReminder_expForm()
        endpoint = 'reminder/financialreminder/'
        if request.method=="POST":
            form=FinancialReminder_expForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                Output['notify']=id
                Output['reminder_type']='Payable'
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('financialreminder')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('financialreminder_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'fin_pay.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records
        }
        return render(request,'fin_pay.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def financialreminder_edit(request,pk):
    try:

        token = request.session['user_token']


        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        financialreminder = call_get_method(BASEURL, f'reminder/financialreminder/{pk}/',token)
        
        if financialreminder.status_code in [200,201]:
            financialreminder_data = financialreminder.json()
        else:
            print('error------',financialreminder)
            messages.error(request, 'Failed to retrieve data for financialreminder. Please check your connection and try again.', extra_tags='warning')
            return redirect('financialreminder')

        if request.method=="POST":
            form=FinancialReminderForm(request.POST,files = request.FILES, initial=financialreminder_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'reminder/financialreminder/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'financialreminder successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('financialreminder') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                print("=================",form.errors)
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('financialreminder_edit.html', {'form': form,'financialreminder_id': pk,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = FinancialReminderForm(initial=financialreminder_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('financialreminder_edit.html', {'form': form, 'financialreminder_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form,
            'financialreminder_id': pk,
        }
        return render(request,'financialreminder_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def financialreminder_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'reminder/financialreminder/{pk}/'
        financialreminder = call_delete_method(BASEURL, end_point,token)
        if financialreminder.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for financialreminder. Please try again.', extra_tags='warning')
            return redirect('financialreminder')
        else:
            messages.success(request, 'Successfully deleted data for financialreminder', extra_tags='success')
            return redirect('financialreminder')

    except Exception as error:
        return render(request,'500.html',{'error':error})

# create and view table function
@custom_login_required
def notifications(request):
    try:
        token = request.session['user_token']


        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
        notifications_recor = call_get_method(BASEURL, 'reminder/recording/', token)
        if notifications_recor.status_code in [200,201]:
            notifications_record = notifications_recor.json()
        else:
            notifications_record = []
        print("notifications_record",notifications_record)
    
    

        form=FinancialReminderForm()
        endpoint = 'reminder/notification/'
        if request.method=="POST":
            form=FinancialReminderForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('financialreminder')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('financialreminder_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'notifications.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records,
                    'notifications':notifications_record,
                     "file_base_url": settings.FILE_BASE_URL,
                    
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records,
            'notifications':notifications_record,
             "file_base_url": settings.FILE_BASE_URL,
        }
        return render(request,'notifications.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})
    
def financialreminder_pay(request):
    if request.method == 'POST':
        token = request.session['user_token']
        endpoint = 'reminder/notification/'
        print("all value",request.POST)

        Output={
            'from_account':request.POST.get('from_account'),
            'to_account':request.POST.get('to_account'),
            'record_id':request.POST.get('record_id'),
            'amount':request.POST.get('amount'),
        }
        print("Output",Output)
        json_data=json.dumps(Output)
        response = call_post_with_method(BASEURL,endpoint,json_data,token)
        if response.status_code in [200,201]:
            print("error",response)
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'success': True})
            messages.success(request, 'Data Successfully Saved', extra_tags="success")
        return redirect('financialreminder')
def voice(request):
    token = request.session['user_token']

    if request.method == 'POST':
        print("==request==", request.POST)
        print("==request file==", request.FILES)
        endpoint = 'reminder/recording/'
        latitude = request.POST.get("latitude")
        longitude = request.POST.get("longitude")
        location_name = request.POST.get("location_name")
        recording_duration = request.POST.get("recording_duration")

        Output = {
            'latitude': latitude,
            'longitude': longitude,
            'location_name': location_name,
            'recording_duration': recording_duration,
        }
        files = request.FILES.get('voice')
        file = {'files': files}

        response = call_post_with_file_method(BASEURL, endpoint, Output, token, files=file)

        if response.status_code in [200, 201]:
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'redirect_url': '/reminder/notifications/'
                })
            messages.success(request, 'Data Successfully Saved', extra_tags="success")
            return redirect('notifications')
        else:
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': False,
                    'error': response.json()
                })
            messages.error(request, 'Error saving data', extra_tags='danger')
            return redirect('notifications')

    return render(request,'voice.html')

def res_pay(request,id):
    token = request.session['user_token']
    response = call_get_method(BASEURL, f'my_money/ResPayTransaction/{id}',token)
    if response.status_code in [200,201]:
        records = response.json()
    else:
        records = []
    print('record',records)
    return render(request,'res_pay.html',{"record":records})

def TransFinancial(request,id):
    token = request.session['user_token']
    response = call_get_method(BASEURL, f'reminder/TransFinancial/{id}',token)
    if response.status_code in [200,201]:
        records = response.json()
    else:
        records = []
    print('record',records)
    return render(request,'trans_res.html',{"data":records})

def notify_delete(request,pk):
    token = request.session['user_token']
    response = call_get_method(BASEURL, f'reminder/notify/{pk}',token)
    if response.status_code in [200,201]:
        records = response.json()
    else:
        records = []
    print('record',records)
    return redirect('notifications')

def reszor(request):
    print("its comming")
    token = request.session['user_token']
    Output = {
        "name": 'name',
        "email": 'email@gmail.com',
        "phone_no": '11223455',
        "amount": 200,
        'ticket':'ticket',
        'project_id':'project_id'
    }
    endpoint='/RaizorPayment/apipay/'
    json_data=json.dumps(Output)
    response = call_post_with_method(BASEURL,endpoint,json_data,token)
    if response.status_code in [200, 201]:
        print("okay----", response)
        return HttpResponse(response.text)  # 👈 This renders that HTML
    else:
        print("error----", response)
        return HttpResponse("Error while calling payment API", status=500)


def change_status(request,id):
    token = request.session['user_token']
    data={
        
    }
    response = call_post_with_method(BASEURL, f'reminder/change_status/{id}/',data,token)
    if response.status_code in [200,201]:
        records = response.json()
    else:
        records = []
    print('record',records)
    return redirect('specific_rem')

def specific_rem(request):
    token = request.session['user_token']
    
    response = call_get_method(BASEURL, f'reminder/specificNotification/',token)
    if response.status_code in [200,201]:
        records = response.json()
    else:
        records = []
    print('record',records)
    return render(request,'specif_notifications.html',{"data":records,'file_base_url':settings.FILE_BASE_URL})