from django import forms
from .models import *
from django.forms import BaseFormSet,DateInput, DateTimeInput, TimeInput, CheckboxInput, Textarea, TextInput
# from mainapp.forms import GenericModelForm
from django.core.validators import MinValueValidator
from django.core.validators import FileExtensionValidator, MaxValueValidator
from django.utils.safestring import mark_safe
from django.shortcuts import resolve_url

class ForeignKeySelectWithAdd(forms.Select):
    """
    Renders a <select> plus a small '+' button that links to the create page.
    Usage: widget=ForeignKeySelectWithAdd(add_url='company_create')  # URL name or absolute URL
    """
    def __init__(self, add_url=None, open_in_popup=False, *args, **kwargs):
        self.add_url = add_url
        self.open_in_popup = open_in_popup
        super().__init__(*args, **kwargs)

    def render(self, name, value, attrs=None, renderer=None):
        select_html = super().render(name, value, attrs, renderer)
        href = resolve_url(self.add_url) if self.add_url else "#"

        if self.open_in_popup:
            # Open a small popup like Django admin; no template changes required
            add_button_html = (
                f'<a href="{href}" onclick="window.open(this.href, \'popup\', '
                f'\'width=900,height=700,resizable,scrollbars\'); return false;" '
                f'class="btn btn-success btn-sm ml-2" title="Add new">+</a>'
            )
        else:
            add_button_html = (
                f'<a href="{href}" target="_blank" '
                f'class="btn btn-success btn-sm ml-2" title="Add new">+</a>'
            )

        # Wrap neatly; keep your existing form-control on the <select>
        html = (
            '<div style="display:flex; align-items:center; gap:.5rem;">'
            f'{select_html}{add_button_html}'
            '</div>'
        )
        return mark_safe(html)


class WalletForm(forms.Form):
	wallet_name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	# wallet_type = forms.ChoiceField(choices=[('piggybank', 'Piggybank'), ('savings', 'Savings')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	notes = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	initial_amount = forms.FloatField(required=False ,label='Minium Balance', widget=forms.NumberInput(attrs={"class": "form-control","placeholder": 'Set your Minium Balance'}))
	amount = forms.FloatField(required=False,initial=0.0, widget=forms.NumberInput(attrs={"class": "form-control","placeholder": 'Set your Minium Balance'}))


class LockerForm(forms.Form):
	wallet_name = forms.CharField(max_length=100, required=False,label='Locker name', widget=forms.TextInput(attrs={"class": "form-control"}))
	# wallet_type = forms.ChoiceField(choices=[('piggybank', 'Piggybank'), ('savings', 'Savings')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	notes = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	initial_amount = forms.FloatField(required=False ,label='Minium Balance', widget=forms.NumberInput(attrs={"class": "form-control","placeholder": 'Set your Minium Balance'}))
	amount = forms.FloatField(required=False, initial=0.0,widget=forms.NumberInput(attrs={"class": "form-control","placeholder": 'Set your Minium Balance'}))


class PiggyForm(forms.Form):
	wallet_name = forms.CharField(max_length=100, required=False,label='Piggy Bank name', widget=forms.TextInput(attrs={"class": "form-control"}))
	# wallet_type = forms.ChoiceField(choices=[('piggybank', 'Piggybank'), ('savings', 'Savings')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	notes = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	initial_amount = forms.FloatField(required=False,label='Minium Balance', widget=forms.NumberInput(attrs={"class": "form-control","placeholder": 'Set your Minium Balance'}))
	amount = forms.FloatField(required=False,initial=0.0, widget=forms.NumberInput(attrs={"class": "form-control","placeholder": 'Set your Minium Balance'}))


class MyProjectForm(forms.Form):
	nick_name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	# initial_amount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control","placeholder": 'Set your Minium Balance'}))



class ExpenseCategoryForm(forms.Form):
	name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))


class IncomeCategoryForm(forms.Form):
	name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))

class BankAccountForm(forms.Form):
	bank_name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	account_number = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	nick_name = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	account_number = forms.CharField(
		max_length=4,  # xxxx-xxxx-xxxx-1234 → 19 chars including dashes
		required=False,
		help_text="e.g -->xxxx-xxxx-xxxx-1234",
		widget=forms.TextInput(attrs={
			"class": "form-control",
			"placeholder": 'Enter Last four Digit'
		})
	)
	initial_amount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control", 'min':'0',"placeholder": 'Set your Minium Balance'}))
	amount = forms.FloatField( required=False, widget=forms.NumberInput(attrs={"class": "form-control",'min':'0'}))
	account_type = forms.ChoiceField(choices=[('checking', 'Checking'), ('savings', 'Savings')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	notes = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))


class ExpenseForm(forms.Form):
    to_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    category = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "expensecategory",
        "data-field-type": "category",
        "placeholder": "Type to search categories..."
    }))
    from_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    date_received = forms.DateField(
        input_formats=['%Y-%m-%d'],
        required=False, 
        widget=forms.DateInput(attrs={
            "type": "date",
            "class": "form-control"
        })
    )
    amount = forms.FloatField(
        required=False, 
        widget=forms.NumberInput(attrs={
            "class": "form-control",
            "placeholder": "Enter amount"
        })
    )
    my_project = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "myproject",
        "data-field-type": "project",
        "placeholder": "Type to search projects..."
    }))
    description = forms.CharField(
        required=False, 
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "placeholder": "Enter description",
            "rows": 3
        })
    )
    budge_name = forms.CharField(
        max_length=100, 
        required=False, 
        widget=forms.TextInput(attrs={
            "class": "form-control",
            "placeholder": "Enter budget name"
        })
    )
    set_budget_amoun = forms.FloatField(
        required=False, 
        widget=forms.NumberInput(attrs={
            "class": "form-control",
            "placeholder": "Enter budget amount"
        })
    )
 


    def __init__(self, *args, **kwargs):
        to_account_list = kwargs.pop('to_account_choice', [])
        contact_records = kwargs.pop('contact_records', [])
        myproject_records_list = kwargs.pop('myproject_records', [])
        category_list = kwargs.pop('category_choice', [])
        from_account_list = kwargs.pop('from_account_choice', [])
        initial_data = kwargs.get("initial", {})

        super().__init__(*args, **kwargs)

        # Merge accounts + contacts
        account_and_contacts = []

        # Add accounts
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('nick_name', '')}-{record.get('account_type', '')}",
                'type': 'account'
            } for record in (to_account_list)
        ])

        # Add contacts
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('name', '')}-contact".strip(),
                'type': 'contact'
            } for record in contact_records
        ])

        # Store autocomplete data for frontend
        self.autocomplete_data = {
            'accounts': account_and_contacts,
            'categories': [{
                'id': record.get('id', ''),
                'display_name': record.get('name', '')
            } for record in category_list],
            'projects': [{
                'id': record.get('id', ''),
                'display_name': record.get('nick_name', ''),
                # 'set_budget_amt': record.get('set_budget_amt', '')
            } for record in myproject_records_list]
        }

        # --- Set initial values ---
        if initial_data:
            to_account_id = initial_data.get('to_account', '')
            if to_account_id:
                account = next((a for a in self.autocomplete_data['accounts'] if str(a['id']) == str(to_account_id)), None)
                if account:
                    self.fields['to_account'].initial = account['display_name']
                    self.fields['to_account_id'].initial = to_account_id

            from_account_id = initial_data.get('from_account', '')
            if from_account_id:
                account = next((a for a in self.autocomplete_data['accounts'] if str(a['id']) == str(from_account_id)), None)
                if account:
                    self.fields['from_account'].initial = account['display_name']
                    self.fields['from_account_id'].initial = from_account_id

            category_id = initial_data.get('category', '')
            if category_id:
                category = next((c for c in self.autocomplete_data['categories'] if str(c['id']) == str(category_id)), None)
                if category:
                    self.fields['category'].initial = category['display_name']
                    self.fields['category_id'].initial = category_id

            my_project_id = initial_data.get('my_project', '')
            if my_project_id:
                project = next((p for p in self.autocomplete_data['projects'] if str(p['id']) == str(my_project_id)), None)
                if project:
                    self.fields['my_project'].initial = project['display_name']
                    self.fields['my_project_id'].initial = my_project_id


class ExpenseFormEdit(forms.Form):
    to_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    category = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "expensecategory",
        "data-field-type": "category",
        "placeholder": "Type to search categories..."
    }))
    from_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    date_received = forms.DateField(
        input_formats=['%Y-%m-%d'],
        required=False, 
        widget=forms.DateInput(attrs={
            "type": "date",
            "class": "form-control"
        })
    )
    amount = forms.FloatField(
        required=False, 
        widget=forms.NumberInput(attrs={
            "class": "form-control",
            "placeholder": "Enter amount"
        })
    )
    my_project = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "myproject",
        "data-field-type": "project",
        "placeholder": "Type to search projects..."
    }))
    description = forms.CharField(
        required=False, 
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "placeholder": "Enter description",
            "rows": 3
        })
    )
    budge_name = forms.CharField(
        max_length=100, 
        required=False, 
        widget=forms.TextInput(attrs={
            "class": "form-control",
            "placeholder": "Enter budget name"
        })
    )
    set_budget_amoun = forms.FloatField(
        required=False, 
        widget=forms.NumberInput(attrs={
            "class": "form-control",
            "placeholder": "Enter budget amount"
        })
    )

    # --- Hidden ID fields like in IncomeFormEdit ---
    to_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
    from_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
    category_id = forms.CharField(required=False, widget=forms.HiddenInput())
    my_project_id = forms.CharField(required=False, widget=forms.HiddenInput())

    def __init__(self, *args, **kwargs):
        to_account_list = kwargs.pop('to_account_choice', [])
        from_account_list = kwargs.pop('from_account_choice', [])
        contact_records = kwargs.pop('contact_records', [])
        myproject_records_list = kwargs.pop('myproject_records', [])
        category_list = kwargs.pop('category_choice', [])
        initial_data = kwargs.get("initial", {})

        super().__init__(*args, **kwargs)

        # Merge accounts + contacts
        account_and_contacts = []

        # Add accounts (from to_account_list)
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('nick_name', '')}-{record.get('account_type', '')}".strip(),
                'type': 'account'
            } for record in to_account_list
        ])

        # Add contacts
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('name', '')}-contact".strip(),
                'type': 'contact'
            } for record in contact_records
        ])

        # --- Prepare autocomplete data ---
        self.autocomplete_data = {
            'accounts': account_and_contacts,
            'categories': [
                {'id': c.get('id', ''), 'display_name': c.get('name', '')}
                for c in category_list
            ],
            'projects': [
                {'id': p.get('id', ''), 'display_name': p.get('nick_name', '')}
                for p in myproject_records_list
            ]
        }

        # --- Lookup dictionaries for mapping IDs → display names ---
        accounts_lookup = {str(a['id']): a['display_name'] for a in account_and_contacts}
        categories_lookup = {str(c['id']): c['display_name'] for c in self.autocomplete_data['categories']}
        projects_lookup = {str(p['id']): p['display_name'] for p in self.autocomplete_data['projects']}

        # --- Set initial values ---
        if initial_data:
            # To Account
            to_account_id = str(initial_data.get('to_account', ''))
            if to_account_id:
                display_name = accounts_lookup.get(to_account_id, to_account_id)
                self.fields['to_account'].initial = display_name
                self.fields['to_account_id'].initial = to_account_id

            # From Account
            from_account_id = str(initial_data.get('from_account', ''))
            if from_account_id:
                display_name = accounts_lookup.get(from_account_id, from_account_id)
                self.fields['from_account'].initial = display_name
                self.fields['from_account_id'].initial = from_account_id

            # Category
            category_id = str(initial_data.get('category', ''))
            if category_id:
                display_name = categories_lookup.get(category_id, category_id)
                self.fields['category'].initial = display_name
                self.fields['category_id'].initial = category_id

            # Project
            my_project_id = str(initial_data.get('my_project', ''))
            if my_project_id:
                display_name = projects_lookup.get(my_project_id, my_project_id)
                self.fields['my_project'].initial = display_name
                self.fields['my_project_id'].initial = my_project_id


# class IncomeForm(forms.Form):
# 	from_source_account = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="bankaccount", open_in_popup=True,attrs={"class": "form-control"}))
# 	category = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="incomecategory", open_in_popup=True,attrs={"class": "form-control"}))
# 	to_account = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="bankaccount", open_in_popup=True,attrs={"class": "form-control"}))
# 	date_received = forms.DateField(input_formats=['%Y-%m-%d'],required=False, widget=forms.DateInput(attrs={"type": "date","class": "form-control"}))
# 	amount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control" , }))
# 	my_project = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="myproject", open_in_popup=True,attrs={"class": "form-control"}))
# 	description = forms.CharField(required=False, widget=forms.Textarea(attrs={"class": "form-control"}))
# 	def __init__(self, *args, **kwargs):
# 		from_source_account_list = kwargs.pop('from_source_account_choice', [])
# 		myproject_records_list = kwargs.pop('myproject_records', [])
# 		initial_data = kwargs.get("initial", {})
# 		selected_from_source_account = initial_data.get('from_source_account', '')
# 		category_list = kwargs.pop('category_choice', [])
# 		selected_category = initial_data.get('category', '')
# 		selected_myproject = initial_data.get('myproject_records', '')
# 		to_account_list = kwargs.pop('to_account_choice', [])
# 		selected_to_account = initial_data.get('to_account', '')
# 		super().__init__(*args, **kwargs)
# 		self.fields['from_source_account'].choices = [('', '---select---')] + [(record.get('id', ''), f"{record.get('bank_name', '')}-{record.get('account_type', '')}",) for record in from_source_account_list]
# 		self.fields['category'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('name', '')) for record in category_list]
# 		self.fields['to_account'].choices = [('', '---select---')] + [(record.get('id', ''), f"{record.get('bank_name', '')}-{record.get('account_type', '')}") for record in to_account_list]
# 		self.fields['my_project'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('nick_name', '')) for record in myproject_records_list]
# 		if selected_from_source_account:
# 			self.fields['from_source_account'].initial = selected_from_source_account
# 		if selected_category:
# 			self.fields['category'].initial = selected_category
# 		if selected_to_account:
# 			self.fields['to_account'].initial = selected_to_account
# 		if selected_myproject:
# 			self.fields['my_project'].initial = selected_myproject

class IncomeForm(forms.Form):
    from_source_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    category = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "incomecategory",
        "data-field-type": "category",
        "placeholder": "Type to search categories..."
    }))
    to_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    date_received = forms.DateField(
        input_formats=['%Y-%m-%d'],
        required=False, 
        widget=forms.DateInput(attrs={
            "type": "date",
            "class": "form-control"
        })
    )
    amount = forms.FloatField(
        required=False, 
        widget=forms.NumberInput(attrs={
            "class": "form-control",
            "placeholder": "Enter amount"
        })
    )
    my_project = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "myproject",
        "data-field-type": "project",
        "placeholder": "Type to search projects..."
    }))
    description = forms.CharField(
        required=False, 
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "placeholder": "Enter description",
            "rows": 3
        })
    )
    
    # Hidden fields to store the actual ID values
    # from_source_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
    # category_id = forms.CharField(required=False, widget=forms.HiddenInput())
    # to_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
    # my_project_id = forms.CharField(required=False, widget=forms.HiddenInput())
    
    def __init__(self, *args, **kwargs):
        from_source_account_list = kwargs.pop('from_source_account_choice', [])
        myproject_records_list = kwargs.pop('myproject_records', [])
        initial_data = kwargs.get("initial", {})
        category_list = kwargs.pop('category_choice', [])
        to_account_list = kwargs.pop('to_account_choice', [])
        contact_records = kwargs.pop('contact_records', [])

        super().__init__(*args, **kwargs)
        # Merge accounts + contacts
        account_and_contacts = []

        # Add accounts
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('nick_name', '')}-{record.get('account_type', '')}",
                'type': 'account'
            } for record in (to_account_list)
        ])

        # Add contacts
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('name', '')}-contact".strip(),
                'type': 'contact'
            } for record in contact_records 
        ])
        # Store the data lists as instance variables for use in the template
        self.autocomplete_data = {
            'accounts': account_and_contacts,
            'categories': [{
                'id': record.get('id', ''),
                'display_name': record.get('name', '')
            } for record in category_list],
            'projects': [{
                'id': record.get('id', ''),
                'display_name': record.get('nick_name', '')
            } for record in myproject_records_list]
        }
        
        # Set initial values for text fields based on IDs
        if initial_data:
            from_source_account_id = initial_data.get('from_source_account', '')
            if from_source_account_id:
                account = next((a for a in self.autocomplete_data['accounts'] if str(a['id']) == str(from_source_account_id)), None)
                if account:
                    self.fields['from_source_account'].initial = account['display_name']
                    self.fields['from_source_account_id'].initial = from_source_account_id
            
            category_id = initial_data.get('category', '')
            if category_id:
                category = next((c for c in self.autocomplete_data['categories'] if str(c['id']) == str(category_id)), None)
                if category:
                    self.fields['category'].initial = category['display_name']
                    self.fields['category_id'].initial = category_id
            
            to_account_id = initial_data.get('to_account', '')
            if to_account_id:
                account = next((a for a in self.autocomplete_data['accounts'] if str(a['id']) == str(to_account_id)), None)
                if account:
                    self.fields['to_account'].initial = account['display_name']
                    self.fields['to_account_id'].initial = to_account_id
            
            my_project_id = initial_data.get('my_project', '')  
            if my_project_id:
                project = next((p for p in self.autocomplete_data['projects'] if str(p['id']) == str(my_project_id)), None)
                if project:
                    self.fields['my_project'].initial = project['display_name']
                    self.fields['my_project_id'].initial = my_project_id

# my_money/forms.py

from django import forms

class IncomeFormEdit(forms.Form):
    from_source_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    category = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "incomecategory",
        "data-field-type": "category",
        "placeholder": "Type to search categories..."
    }))
    to_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "bankaccount",
        "data-field-type": "account",
        "placeholder": "Type to search accounts..."
    }))
    date_received = forms.DateField(
        input_formats=['%Y-%m-%d'],
        required=False, 
        widget=forms.DateInput(attrs={
            "type": "date",
            "class": "form-control"
        })
    )
    amount = forms.FloatField(
        required=False, 
        widget=forms.NumberInput(attrs={
            "class": "form-control",
            "placeholder": "Enter amount"
        })
    )
    my_project = forms.CharField(required=False, widget=forms.TextInput(attrs={
        "class": "form-control autocomplete-field",
        "data-url": "myproject",
        "data-field-type": "project",
        "placeholder": "Type to search projects..."
    }))
    description = forms.CharField(
        required=False, 
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "placeholder": "Enter description",
            "rows": 3
        })
    )

    # Hidden fields to store the actual ID values
    from_source_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
    category_id = forms.CharField(required=False, widget=forms.HiddenInput())
    to_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
    my_project_id = forms.CharField(required=False, widget=forms.HiddenInput())

    def __init__(self, *args, **kwargs):
        from_source_account_list = kwargs.pop('from_source_account_choice', [])
        myproject_records_list = kwargs.pop('myproject_records', [])
        initial_data = kwargs.get("initial", {})
        category_list = kwargs.pop('category_choice', [])
        to_account_list = kwargs.pop('to_account_choice', [])
        contact_records = kwargs.pop('contact_records', [])

        super().__init__(*args, **kwargs)
        
        # Merge accounts + contacts
        account_and_contacts = []

        # Add accounts
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('nick_name', '')}-{record.get('account_type', '')}",
                'type': 'account'
            } for record in (to_account_list)
        ])

        # Add contacts
        account_and_contacts.extend([
            {
                'id': record.get('id', ''),
                'display_name': f"{record.get('name', '')}-contact".strip(),
                'type': 'contact'
            } for record in contact_records 
        ])
        
        # Store the data lists as instance variables for use in the template
        self.autocomplete_data = {
            'accounts': account_and_contacts,
            'categories': [{
                'id': record.get('id', ''),
                'display_name': record.get('name', '')
            } for record in category_list],
            'projects': [{
                'id': record.get('id', ''),
                'display_name': record.get('nick_name', '')
            } for record in myproject_records_list]
        }
        
        # print("DEBUG - Autocomplete data accounts:", [f"{a['id']}: {a['display_name']}" for a in account_and_contacts])
        # print("DEBUG - Autocomplete data categories:", [f"{c['id']}: {c['display_name']}" for c in self.autocomplete_data['categories']])
        # print("DEBUG - Autocomplete data projects:", [f"{p['id']}: {p['display_name']}" for p in self.autocomplete_data['projects']])
        # print("DEBUG - Initial data:", initial_data)
        
        # Create lookup dictionaries for mapping IDs to display names
        accounts_lookup = {str(item['id']): item['display_name'] for item in account_and_contacts}
        categories_lookup = {str(item['id']): item['display_name'] for item in self.autocomplete_data['categories']}
        projects_lookup = {str(item['id']): item['display_name'] for item in self.autocomplete_data['projects']}
        
       
        
        # Set initial values by mapping IDs to display names
        if initial_data:
            # From Source Account
            from_source_account_id = str(initial_data.get('from_source_account', ''))
            if from_source_account_id:
                display_name = accounts_lookup.get(from_source_account_id, from_source_account_id)
                self.fields['from_source_account'].initial = display_name
                self.fields['from_source_account_id'].initial = from_source_account_id
                print(f"DEBUG - From Source: ID={from_source_account_id}, Display={display_name}")
            
            # Category
            category_id = str(initial_data.get('category', ''))
            if category_id:
                display_name = categories_lookup.get(category_id, category_id)
                self.fields['category'].initial = display_name
                self.fields['category_id'].initial = category_id
                print(f"DEBUG - Category: ID={category_id}, Display={display_name}")
            
            # To Account
            to_account_id = str(initial_data.get('to_account', ''))
            if to_account_id:
                display_name = accounts_lookup.get(to_account_id, to_account_id)
                self.fields['to_account'].initial = display_name
                self.fields['to_account_id'].initial = to_account_id
                print(f"DEBUG - To Account: ID={to_account_id}, Display={display_name}")
            
            # My Project
            my_project_id = str(initial_data.get('my_project', ''))
            if my_project_id:
                display_name = projects_lookup.get(my_project_id, my_project_id)
                self.fields['my_project'].initial = display_name
                self.fields['my_project_id'].initial = my_project_id
                print(f"DEBUG - Project: ID={my_project_id}, Display={display_name}")

# class IncomeForm(forms.Form): this worked good
#     from_source_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
#         "class": "form-control autocomplete-field",
#         "data-url": "bankaccount",
#         "data-field-type": "account",
#         "placeholder": "Type to search accounts..."
#     }))
#     category = forms.CharField(required=False, widget=forms.TextInput(attrs={
#         "class": "form-control autocomplete-field",
#         "data-url": "incomecategory",
#         "data-field-type": "category",
#         "placeholder": "Type to search categories..."
#     }))
#     to_account = forms.CharField(required=False, widget=forms.TextInput(attrs={
#         "class": "form-control autocomplete-field",
#         "data-url": "bankaccount",
#         "data-field-type": "account",
#         "placeholder": "Type to search accounts..."
#     }))
#     date_received = forms.DateField(
#         input_formats=['%Y-%m-%d'],
#         required=False, 
#         widget=forms.DateInput(attrs={
#             "type": "date",
#             "class": "form-control"
#         })
#     )
#     amount = forms.FloatField(
#         required=False, 
#         widget=forms.NumberInput(attrs={
#             "class": "form-control",
#             "placeholder": "Enter amount"
#         })
#     )
#     my_project = forms.CharField(required=False, widget=forms.TextInput(attrs={
#         "class": "form-control autocomplete-field",
#         "data-url": "myproject",
#         "data-field-type": "project",
#         "placeholder": "Type to search projects..."
#     }))
#     description = forms.CharField(
#         required=False, 
#         widget=forms.Textarea(attrs={
#             "class": "form-control",
#             "placeholder": "Enter description",
#             "rows": 3
#         })
#     )
    
#     # Hidden fields to store the actual ID values
#     from_source_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
#     category_id = forms.CharField(required=False, widget=forms.HiddenInput())
#     to_account_id = forms.CharField(required=False, widget=forms.HiddenInput())
#     my_project_id = forms.CharField(required=False, widget=forms.HiddenInput())
    
#     def __init__(self, *args, **kwargs):
#         from_source_account_list = kwargs.pop('from_source_account_choice', [])
#         myproject_records_list = kwargs.pop('myproject_records', [])
#         initial_data = kwargs.get("initial", {})
#         category_list = kwargs.pop('category_choice', [])
#         to_account_list = kwargs.pop('to_account_choice', [])
        
#         super().__init__(*args, **kwargs)
        
#         # Store the data lists as instance variables for use in the template
#         self.autocomplete_data = {
#             'accounts': [{
#                 'id': record.get('id', ''),
#                 'display_name': f"{record.get('bank_name', '')}-{record.get('account_type', '')}"
#             } for record in from_source_account_list],
#             'categories': [{
#                 'id': record.get('id', ''),
#                 'display_name': record.get('name', '')
#             } for record in category_list],
#             'projects': [{
#                 'id': record.get('id', ''),
#                 'display_name': record.get('nick_name', '')
#             } for record in myproject_records_list]
#         }
        
#         # Set initial values for text fields based on IDs
#         if initial_data:
#             from_source_account_id = initial_data.get('from_source_account', '')
#             if from_source_account_id:
#                 account = next((a for a in self.autocomplete_data['accounts'] if str(a['id']) == str(from_source_account_id)), None)
#                 if account:
#                     self.fields['from_source_account'].initial = account['display_name']
#                     self.fields['from_source_account_id'].initial = from_source_account_id
            
#             category_id = initial_data.get('category', '')
#             if category_id:
#                 category = next((c for c in self.autocomplete_data['categories'] if str(c['id']) == str(category_id)), None)
#                 if category:
#                     self.fields['category'].initial = category['display_name']
#                     self.fields['category_id'].initial = category_id
            
#             to_account_id = initial_data.get('to_account', '')
#             if to_account_id:
#                 account = next((a for a in self.autocomplete_data['accounts'] if str(a['id']) == str(to_account_id)), None)
#                 if account:
#                     self.fields['to_account'].initial = account['display_name']
#                     self.fields['to_account_id'].initial = to_account_id
            
#             my_project_id = initial_data.get('my_project', '')
#             if my_project_id:
#                 project = next((p for p in self.autocomplete_data['projects'] if str(p['id']) == str(my_project_id)), None)
#                 if project:
#                     self.fields['my_project'].initial = project['display_name']
#                     self.fields['my_project_id'].initial = my_project_id

class SavingsGoalForm(forms.Form):
	title = forms.CharField(max_length=255, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	set_goal_ammount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control",}))
	deadline = forms.DateField(input_formats=['%Y-%m-%d'],required=False, widget=forms.DateInput(attrs={"type": "date","class": "form-control"}))
	current_amount = forms.FloatField(required=False,label="Initial Amount", widget=forms.NumberInput(attrs={"class": "form-control",}))
	type_of_saving = forms.ChoiceField(choices=[('Physical', 'Physical'), ('Online', 'Online')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	online_account = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="bankaccount", open_in_popup=True,attrs={"class": "form-control"}))
	physical_account = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="wallet", open_in_popup=True,attrs={"class": "form-control"}))
	notes = forms.CharField(required=False, widget=forms.Textarea(attrs={"class": "form-control"}))
	def __init__(self, *args, **kwargs):
		online_account_list = kwargs.pop('online_account_choice', [])
		initial_data = kwargs.get("initial", {})
		selected_online_account = initial_data.get('online_account', '')
		physical_account_list = kwargs.pop('physical_account_choice', [])
		selected_physical_account = initial_data.get('physical_account', '')
		super().__init__(*args, **kwargs)
		self.fields['online_account'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('nick_name', '')) for record in online_account_list]
		self.fields['physical_account'].choices = [('', '---select---')] + [(record.get('id', ''),f" {record.get('nick_name', '')}-{record.get('account_type', '')}") for record in physical_account_list]
		if selected_online_account:
			self.fields['online_account'].initial = selected_online_account
		if selected_physical_account:
			self.fields['physical_account'].initial = selected_physical_account



class TransactionForm(forms.Form):
	from_account = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="bankaccount", open_in_popup=True,attrs={"class": "form-control"}))
	to_account = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="bankaccount", open_in_popup=True,attrs={"class": "form-control"}))
	amount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control"}))
	payment_mode = forms.ChoiceField(choices=[('cash', 'Cash'), ('card', 'Card'), ('bank_transfer', 'Bank_transfer'), ('upi', 'Upi'), ('other', 'Other')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	date = forms.DateField(input_formats=['%Y-%m-%d'],required=False, widget=forms.DateInput(attrs={"type": "date","class": "form-control"}))
	def __init__(self, *args, **kwargs):
		from_account_list = kwargs.pop('from_account_choice', [])
		initial_data = kwargs.get("initial", {})
		selected_from_account = initial_data.get('from_account', '')
		to_account_list = kwargs.pop('to_account_choice', [])
		selected_to_account = initial_data.get('to_account', '')
		super().__init__(*args, **kwargs)
		self.fields['from_account'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('nick_name', '')) for record in from_account_list]
		self.fields['to_account'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('nick_name', '')) for record in to_account_list]
		if selected_from_account:
			self.fields['from_account'].initial = selected_from_account
		if selected_to_account:
			self.fields['to_account'].initial = selected_to_account



class ExpensevirtualForm(forms.Form):
	expense = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="expense", open_in_popup=True,attrs={"class": "form-control"}))
	virtual_account = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	amount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control" , }))
	description = forms.CharField(required=False, widget=forms.Textarea(attrs={"class": "form-control"}))
	def __init__(self, *args, **kwargs):
		expense_list = kwargs.pop('expense_choice', [])
		initial_data = kwargs.get("initial", {})
		selected_expense = initial_data.get('expense', '')
		super().__init__(*args, **kwargs)
		self.fields['expense'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('date_received', '')) for record in expense_list]
		if selected_expense:
			self.fields['expense'].initial = selected_expense



class IncomevirtualForm(forms.Form):
	income = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="income", open_in_popup=True,attrs={"class": "form-control"}))
	virtual_account = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	amount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control" , }))
	description = forms.CharField(required=False, widget=forms.Textarea(attrs={"class": "form-control"}))
	def __init__(self, *args, **kwargs):
		income_list = kwargs.pop('income_choice', [])
		initial_data = kwargs.get("initial", {})
		selected_income = initial_data.get('income', '')
		super().__init__(*args, **kwargs)
		self.fields['income'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('date_received', '')) for record in income_list]
		if selected_income:
			self.fields['income'].initial = selected_income



class ContributionForm(forms.Form):
	savings_goal = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="savingsgoal", open_in_popup=True,attrs={"class": "form-control"}))
	amount = forms.FloatField(required=False, widget=forms.NumberInput(attrs={"class": "form-control"}))
	from_account = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="bankaccount", open_in_popup=True,attrs={"class": "form-control"}))
	date = forms.DateField(input_formats=['%Y-%m-%d'],required=False, widget=forms.DateInput(attrs={"type": "date","class": "form-control"}))
	note = forms.CharField(required=False, widget=forms.Textarea(attrs={"class": "form-control"}))
	def __init__(self, *args, **kwargs):
		savings_goal_list = kwargs.pop('savings_goal_choice', [])
		initial_data = kwargs.get("initial", {})
		selected_savings_goal = initial_data.get('savings_goal', '')
		from_account_list = kwargs.pop('from_account_choice', [])
		selected_from_account = initial_data.get('from_account', '')
		super().__init__(*args, **kwargs)
		self.fields['savings_goal'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('title', '')) for record in savings_goal_list]
		self.fields['from_account'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('nick_name', '')) for record in from_account_list]
		if selected_savings_goal:
			self.fields['savings_goal'].initial = selected_savings_goal
		if selected_from_account:
			self.fields['from_account'].initial = selected_from_account

