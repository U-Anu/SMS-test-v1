from django.http import JsonResponse
from django.shortcuts import render, redirect
from .forms import *
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.forms import formset_factory
from django.forms import modelformset_factory
from mainapp.views import *
from django.template.loader import render_to_string

APP_NAME = __name__.split('.')[0]

BASEURL = settings.BASEURL


# create and view table function
@custom_login_required
def wallet(request):
    try:
        token = request.session['user_token']
        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
        form=WalletForm()
        endpoint = 'my_money/wallet/'
        if request.method=="POST":
            form=WalletForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                Output['wallet_type']='wallet'
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('wallet')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('wallet_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'wallet.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records
        }
        return render(request,'wallet.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def wallet_edit(request,pk):
    try:

        token = request.session['user_token']



        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        wallet = call_get_method(BASEURL, f'my_money/wallet/{pk}/',token)
        
        if wallet.status_code in [200,201]:
            wallet_data = wallet.json()
        else:
            print('error------',wallet)
            messages.error(request, 'Failed to retrieve data for wallet. Please check your connection and try again.', extra_tags='warning')
            return redirect('wallet')

        if request.method=="POST":
            form=WalletForm(request.POST,files = request.FILES, initial=wallet_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/wallet/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'wallet successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('wallet') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('wallet_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = WalletForm(initial=wallet_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('wallet_edit.html', {'form': form, 'wallet_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'wallet_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def wallet_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/wallet/{pk}/'
        wallet = call_delete_method(BASEURL, end_point,token)
        if wallet.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for wallet. Please try again.', extra_tags='warning')
            return redirect('wallet')
        else:
            messages.success(request, 'Successfully deleted data for wallet', extra_tags='success')
            return redirect('wallet')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def expensecategory(request):
    try:
        token = request.session['user_token']


        form=ExpenseCategoryForm()
        endpoint = 'my_money/expensecategory/'
        if request.method=="POST":
            form=ExpenseCategoryForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('expensecategory')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('expensecategory_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'expensecategory.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'expensecategory.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def expensecategory_edit(request,pk):
    try:

        token = request.session['user_token']



        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        expensecategory = call_get_method(BASEURL, f'my_money/expensecategory/{pk}/',token)
        
        if expensecategory.status_code in [200,201]:
            expensecategory_data = expensecategory.json()
        else:
            print('error------',expensecategory)
            messages.error(request, 'Failed to retrieve data for expensecategory. Please check your connection and try again.', extra_tags='warning')
            return redirect('expensecategory')

        if request.method=="POST":
            form=ExpenseCategoryForm(request.POST,files = request.FILES, initial=expensecategory_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/expensecategory/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'expensecategory successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('expensecategory') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('expensecategory_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = ExpenseCategoryForm(initial=expensecategory_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('expensecategory_edit.html', {'form': form, 'expensecategory_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'expensecategory_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def expensecategory_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/expensecategory/{pk}/'
        expensecategory = call_delete_method(BASEURL, end_point,token)
        if expensecategory.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for expensecategory. Please try again.', extra_tags='warning')
            return redirect('expensecategory')
        else:
            messages.success(request, 'Successfully deleted data for expensecategory', extra_tags='success')
            return redirect('expensecategory')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def incomecategory(request):
    try:
        token = request.session['user_token']


        form=IncomeCategoryForm()
        endpoint = 'my_money/incomecategory/'
        if request.method=="POST":
            form=IncomeCategoryForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('incomecategory')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('incomecategory_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'incomecategory.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'incomecategory.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def incomecategory_edit(request,pk):
    try:

        token = request.session['user_token']



        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        incomecategory = call_get_method(BASEURL, f'my_money/incomecategory/{pk}/',token)
        
        if incomecategory.status_code in [200,201]:
            incomecategory_data = incomecategory.json()
        else:
            print('error------',incomecategory)
            messages.error(request, 'Failed to retrieve data for incomecategory. Please check your connection and try again.', extra_tags='warning')
            return redirect('incomecategory')

        if request.method=="POST":
            form=IncomeCategoryForm(request.POST,files = request.FILES, initial=incomecategory_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/incomecategory/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'incomecategory successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('incomecategory') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('incomecategory_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = IncomeCategoryForm(initial=incomecategory_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('incomecategory_edit.html', {'form': form, 'incomecategory_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'incomecategory_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def incomecategory_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/incomecategory/{pk}/'
        incomecategory = call_delete_method(BASEURL, end_point,token)
        if incomecategory.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for incomecategory. Please try again.', extra_tags='warning')
            return redirect('incomecategory')
        else:
            messages.success(request, 'Successfully deleted data for incomecategory', extra_tags='success')
            return redirect('incomecategory')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def bankaccount(request):
    # try:
        token = request.session['user_token']


        wallet_response = call_get_method(BASEURL, 'my_money/wallet/', token)
        if wallet_response.status_code in [200,201]:
            wallet_records = wallet_response.json()
        else:
            wallet_records = []
            
        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []

        form=BankAccountForm()
        endpoint = 'my_money/bankaccount/'
        if request.method=="POST":
            form=BankAccountForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                Output['account_category']='my account'
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                print("json_data097809",json_data)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('bankaccount')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('bankaccount_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'bankaccount.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records,
        }
        return render(request,'bankaccount.html',context)

    # except Exception as error:
    #     return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def otheraccount(request):
    try:
        token = request.session['user_token']
        form=BankAccountForm()
        endpoint = 'my_money/otheraccount/'
        if request.method=="POST":
            form=BankAccountForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                Output['account_category']='other account'
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                print("json_data097809",json_data)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('bankaccount')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('bankaccount_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'otheraccounts.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'otheraccounts.html.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def bankaccount_edit(request,pk):
    try:

        token = request.session['user_token']


        wallet_response = call_get_method(BASEURL, 'my_money/wallet/', token)
        if wallet_response.status_code in [200,201]:
            wallet_records = wallet_response.json()
        else:
            wallet_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        bankaccount = call_get_method(BASEURL, f'my_money/bankaccount/{pk}/',token)
        
        if bankaccount.status_code in [200,201]:
            bankaccount_data = bankaccount.json()
        else:
            print('error------',bankaccount)
            messages.error(request, 'Failed to retrieve data for bankaccount. Please check your connection and try again.', extra_tags='warning')
            return redirect('bankaccount')

        if request.method=="POST":
            form=BankAccountForm(request.POST,files = request.FILES, initial=bankaccount_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/bankaccount/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'bankaccount successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('bankaccount') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('bankaccount_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = BankAccountForm(initial=bankaccount_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('bankaccount_edit.html', {'form': form, 'bankaccount_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'bankaccount_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def bankaccount_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/bankaccount/{pk}/'
        bankaccount = call_delete_method(BASEURL, end_point,token)
        if bankaccount.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for bankaccount. Please try again.', extra_tags='warning')
            return redirect('bankaccount')
        else:
            messages.success(request, 'Successfully deleted data for bankaccount', extra_tags='success')
            return redirect('bankaccount')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
from django.core.files.base import ContentFile
import base64
@custom_login_required
def expense(request):
    try:
        token = request.session['user_token']


        to_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []
        myproject_response = call_get_method(BASEURL, 'my_money/myproject/', token)
        if myproject_response.status_code in [200,201]:
           myproject_records =myproject_response.json()
        else:
           myproject_records = []

        category_response = call_get_method(BASEURL, 'my_money/expensecategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []
    

        from_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if from_account_response.status_code in [200,201]:
            from_account_records = from_account_response.json()
        else:
            from_account_records = []
    

        contact = call_get_method(BASEURL, 'personal/contact/', token)
        if contact.status_code in [200,201]:
            contact_records = contact.json()
        else:
            contact_records = []
    

        form=ExpenseForm(to_account_choice=to_account_records,contact_records=contact_records,category_choice=category_records,from_account_choice=from_account_records,myproject_records=myproject_records)
        endpoint = 'my_money/expense/'
        if request.method=="POST":
            form=ExpenseForm(request.POST,files = request.FILES,contact_records=contact_records,to_account_choice=to_account_records,category_choice=category_records,from_account_choice=from_account_records,myproject_records=myproject_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                print("-------=======",json_data)
                file=None
                uploaded_file = request.FILES.get('file')
                if uploaded_file:
                    # Save to model FileField
                    print("uploaded_file",uploaded_file)
                    file={'files':uploaded_file}
                else:
                    # Handle captured image (base64)
                    captured_data = request.POST.get('capturedImage')
                    if captured_data and captured_data.startswith("data:image"):
                        format, imgstr = captured_data.split(';base64,')
                        ext = format.split('/')[-1]  # e.g., png, jpeg
                        data = ContentFile(base64.b64decode(imgstr), name=f"captured.{ext}")
                        # Save to model
                        print('data---img',data)
                response = call_post_with_file_method(BASEURL,endpoint,Output,token,files=file)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('expense')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('expense_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'expense.html', {
                    'form': form,
                    'records': records,
                    "file_base_url": settings.FILE_BASE_URL,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            "file_base_url": settings.FILE_BASE_URL,
        }
        return render(request,'expense.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})
from django.core.files.base import ContentFile
import base64
@custom_login_required
def expense_notify(request,id):
    try:
        token = request.session['user_token']


        to_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []
        myproject_response = call_get_method(BASEURL, 'my_money/myproject/', token)
        if myproject_response.status_code in [200,201]:
           myproject_records =myproject_response.json()
        else:
           myproject_records = []

        category_response = call_get_method(BASEURL, 'my_money/expensecategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []
    

        from_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if from_account_response.status_code in [200,201]:
            from_account_records = from_account_response.json()
        else:
            from_account_records = []

        contact = call_get_method(BASEURL, 'personal/contact/', token)
        if contact.status_code in [200,201]:
            contact_records = contact.json()
        else:
            contact_records = []
    

        form=ExpenseForm(to_account_choice=to_account_records,contact_records=contact_records,category_choice=category_records,from_account_choice=from_account_records,myproject_records=myproject_records)
        endpoint = 'my_money/expense/'
        if request.method=="POST":
            form=ExpenseForm(request.POST,files = request.FILES,contact_records=contact_records,to_account_choice=to_account_records,category_choice=category_records,from_account_choice=from_account_records,myproject_records=myproject_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                Output['notify']=id
                json_data=json.dumps(Output)
                print("-------=======",json_data)
                file=None
                uploaded_file = request.FILES.get('file')
                if uploaded_file:
                    # Save to model FileField
                    print("uploaded_file",uploaded_file)
                    file={'files':uploaded_file}
                else:
                    # Handle captured image (base64)
                    captured_data = request.POST.get('capturedImage')
                    if captured_data and captured_data.startswith("data:image"):
                        format, imgstr = captured_data.split(';base64,')
                        ext = format.split('/')[-1]  # e.g., png, jpeg
                        data = ContentFile(base64.b64decode(imgstr), name=f"captured.{ext}")
                        # Save to model
                        print('data---img',data)
                response = call_post_with_file_method(BASEURL,endpoint,Output,token,files=file)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('expense')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('expense_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'expense_voice.html', {
                    'form': form,
                    'records': records,
                    "file_base_url": settings.FILE_BASE_URL,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            "file_base_url": settings.FILE_BASE_URL,
        }
        return render(request,'expense_voice.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def expense_edit(request,pk):
    try:

        token = request.session['user_token']

        to_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []
        myproject_response = call_get_method(BASEURL, 'my_money/myproject/', token)
        if myproject_response.status_code in [200,201]:
           myproject_records =myproject_response.json()
        else:
           myproject_records = []

        category_response = call_get_method(BASEURL, 'my_money/expensecategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []
    

        from_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if from_account_response.status_code in [200,201]:
            from_account_records = from_account_response.json()
        else:
            from_account_records = []
    

        contact = call_get_method(BASEURL, 'personal/contact/', token)
        if contact.status_code in [200,201]:
            contact_records = contact.json()
        else:
            contact_records = []
    

        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        expense = call_get_method(BASEURL, f'my_money/expense/{pk}/',token)
        
        if expense.status_code in [200,201]:
            expense_data = expense.json()
        else:
            print('error------',expense)
            messages.error(request, 'Failed to retrieve data for expense. Please check your connection and try again.', extra_tags='warning')
            return redirect('expense')

        if request.method=="POST":
            form=ExpenseFormEdit(request.POST,files = request.FILES, initial=expense_data,to_account_choice=to_account_records,category_choice=category_records,from_account_choice=from_account_records,myproject_records=myproject_records,contact_records=contact_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/expense/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'expense successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('expense') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('expense_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = ExpenseFormEdit(initial=expense_data,contact_records=contact_records,to_account_choice=to_account_records,myproject_records=myproject_records,category_choice=category_records,from_account_choice=from_account_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('expense_edit.html', {'form': form, 'expense_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'expense_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def expense_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/expense/{pk}/'
        expense = call_delete_method(BASEURL, end_point,token)
        if expense.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for expense. Please try again.', extra_tags='warning')
            return redirect('expense')
        else:
            messages.success(request, 'Successfully deleted data for expense', extra_tags='success')
            return redirect('expense')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def income(request):
    try:
        token = request.session['user_token']


        from_source_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if from_source_account_response.status_code in [200,201]:
            from_source_account_records = from_source_account_response.json()
        else:
            from_source_account_records = []
    

        category_response = call_get_method(BASEURL, 'my_money/incomecategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []
    

        to_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []
    
        myproject_response = call_get_method(BASEURL, 'my_money/myproject/', token)
        if myproject_response.status_code in [200,201]:
           myproject_records =myproject_response.json()
        else:
           myproject_records = []
    
        contact = call_get_method(BASEURL, 'personal/contact/', token)
        if contact.status_code in [200,201]:
            contact_records = contact.json()
        else:
            contact_records = []
            
        form=IncomeForm(from_source_account_choice=from_source_account_records,contact_records=contact_records,category_choice=category_records,to_account_choice=to_account_records,myproject_records=myproject_records)
        endpoint = 'my_money/income/'
        if request.method=="POST":
            form=IncomeForm(request.POST,files = request.FILES,contact_records=contact_records,from_source_account_choice=from_source_account_records,category_choice=category_records,to_account_choice=to_account_records,myproject_records=myproject_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                print('---------',json_data)
                file=None
                uploaded_file = request.FILES.get('file')
                if uploaded_file:
                    # Save to model FileField
                    print("uploaded_file",uploaded_file)
                    file={'files':uploaded_file}
                else:
                    # Handle captured image (base64)
                    captured_data = request.POST.get('capturedImage')
                    if captured_data and captured_data.startswith("data:image"):
                        format, imgstr = captured_data.split(';base64,')
                        ext = format.split('/')[-1]  # e.g., png, jpeg
                        data = ContentFile(base64.b64decode(imgstr), name=f"captured.{ext}")
                        # Save to model
                        file={'files':data}
                        print('data---img',data)
                response = call_post_with_file_method(BASEURL,endpoint,Output,token,files=file)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('income')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('income_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'income.html', {
                    'form': form,
                    'records': records,
                    "file_base_url": settings.FILE_BASE_URL,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            "file_base_url": settings.FILE_BASE_URL,
        }
        return render(request,'income.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})
@custom_login_required
def income_notify(request,id):
    try:
        print("id1---",id)
        token = request.session['user_token']


        from_source_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if from_source_account_response.status_code in [200,201]:
            from_source_account_records = from_source_account_response.json()
        else:
            from_source_account_records = []
    
        contact = call_get_method(BASEURL, 'personal/contact/', token)
        if contact.status_code in [200,201]:
            contact_records = contact.json()
        else:
            contact_records = []
            
        category_response = call_get_method(BASEURL, 'my_money/incomecategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []
    

        to_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []
    
        myproject_response = call_get_method(BASEURL, 'my_money/myproject/', token)
        if myproject_response.status_code in [200,201]:
           myproject_records =myproject_response.json()
        else:
           myproject_records = []
    

        form=IncomeForm(from_source_account_choice=from_source_account_records,contact_records=contact_records,category_choice=category_records,to_account_choice=to_account_records,myproject_records=myproject_records)
        endpoint = 'my_money/income/'
        if request.method=="POST":
            form=IncomeForm(request.POST,files = request.FILES,contact_records=contact_records,from_source_account_choice=from_source_account_records,category_choice=category_records,to_account_choice=to_account_records,myproject_records=myproject_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                Output['notify']=id
                print("id2---",id)
                json_data=json.dumps(Output)
                
                print('---------',json_data)
                file=None
                uploaded_file = request.FILES.get('file')
                if uploaded_file:
                    # Save to model FileField
                    print("uploaded_file",uploaded_file)
                    file={'files':uploaded_file}
                else:
                    # Handle captured image (base64)
                    captured_data = request.POST.get('capturedImage')
                    if captured_data and captured_data.startswith("data:image"):
                        format, imgstr = captured_data.split(';base64,')
                        ext = format.split('/')[-1]  # e.g., png, jpeg
                        data = ContentFile(base64.b64decode(imgstr), name=f"captured.{ext}")
                        # Save to model
                        file={'files':data}
                        print('data---img',data)
                response = call_post_with_file_method(BASEURL,endpoint,Output,token,files=file)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('income')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('income_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'income_voice.html', {
                    'form': form,
                    'records': records,
                    "file_base_url": settings.FILE_BASE_URL,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            "file_base_url": settings.FILE_BASE_URL,
        }
        return render(request,'income_voice.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# # edit function
# @custom_login_required
# def income_edit(request,pk):
#     # try:

#         token = request.session['user_token']

        

#         from_source_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
#         if from_source_account_response.status_code in [200,201]:
#             from_source_account_records = from_source_account_response.json()
#         else:
#             from_source_account_records = []
    

#         category_response = call_get_method(BASEURL, 'my_money/incomecategory/', token)
#         if category_response.status_code in [200,201]:
#             category_records = category_response.json()
#         else:
#             category_records = []
    

#         to_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
#         if to_account_response.status_code in [200,201]:
#             to_account_records = to_account_response.json()
#         else:
#             to_account_records = []
    
#         myproject_response = call_get_method(BASEURL, 'my_money/myproject/', token)
#         if myproject_response.status_code in [200,201]:
#            myproject_records =myproject_response.json()
#         else:
#            myproject_records = []
    
#         contact = call_get_method(BASEURL, 'personal/contact/', token)
#         if contact.status_code in [200,201]:
#             contact_records = contact.json()
#         else:
#             contact_records = []
            
    


#         mode = request.GET.get('mode', 'edit')  # default to edit if not provided
#         income = call_get_method(BASEURL, f'my_money/income/{pk}/',token)
        
#         if income.status_code in [200,201]:
#             income_data = income.json()
#             print("income_data",income_data)
#         else:
#             print('error------',income)
#             messages.error(request, 'Failed to retrieve data for income. Please check your connection and try again.', extra_tags='warning')
#             return redirect('income')

#         if request.method=="POST":
#             form=IncomeFormEdit(request.POST,files = request.FILES, initial=income_data,contact_records=contact_records,from_source_account_choice=from_source_account_records,category_choice=category_records,to_account_choice=to_account_records,myproject_records=myproject_records)
#             if form.is_valid():
#                 updated_data = form.cleaned_data
#                 updated_data['id'] = pk
#                 for field_name, field in form.fields.items():
#                     if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
#                         if updated_data.get(field_name):
#                             updated_data[field_name] = request.POST.get(field_name)

#                 # Serialize the updated data as JSON
#                 json_data = json.dumps(updated_data)
#                 response = call_put_method(BASEURL, f'my_money/income/{pk}/', json_data,token)

#                 if response.status_code in [200,201]: 
#                     if request.headers.get('x-requested-with') == 'XMLHttpRequest':
#                         return JsonResponse({'success': True})
#                     messages.success(request, 'income successfully updated.', extra_tags='success')
#                     # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
#                     return redirect('income') 
#                 else:
#                     error_message = response.json()
#                     if request.headers.get('x-requested-with') == 'XMLHttpRequest':
#                         return JsonResponse({'success': False, 'error': error_message})
#                     messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
#             else:
#                 if request.headers.get('x-requested-with') == 'XMLHttpRequest':
#                     html = render_to_string('income_edit.html', {'form': form,'mode': mode}, request=request)
#                     return JsonResponse({'success': False, 'formHtml': html})
#                 messages.error(request, "Form validation failed.", extra_tags='danger')
#                 print("An error occurred: Expecting value: line 1 column 1 (char 0)")
#         else:
#             form = IncomeFormEdit(initial=income_data,from_source_account_choice=from_source_account_records,contact_records=contact_records,category_choice=category_records,to_account_choice=to_account_records,myproject_records=myproject_records)

#         if request.headers.get('x-requested-with') == 'XMLHttpRequest':
#             html = render_to_string('income_edit.html', {'form': form, 'income_id': pk,'mode': mode}, request=request)
#             return HttpResponse(html)

#         context={
#             'form':form
#         }
#         return render(request,'income_edit.html',context)
#     # except Exception as error:
#     #     return render(request,'500.html',{'error':error})
@custom_login_required
def income_edit(request, pk):
    try:
        token = request.session['user_token']

        # Fetch all autocomplete data
        from_source_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if from_source_account_response.status_code in [200,201]:
            from_source_account_records = from_source_account_response.json()
        else:
            from_source_account_records = []

        category_response = call_get_method(BASEURL, 'my_money/incomecategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []

        to_account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []

        myproject_response = call_get_method(BASEURL, 'my_money/myproject/', token)
        if myproject_response.status_code in [200,201]:
           myproject_records = myproject_response.json()
        else:
           myproject_records = []

        contact = call_get_method(BASEURL, 'personal/contact/', token)
        if contact.status_code in [200,201]:
            contact_records = contact.json()
        else:
            contact_records = []

        # Get income data
        income = call_get_method(BASEURL, f'my_money/income/{pk}/', token)
        
        if income.status_code in [200,201]:
            income_data = income.json()
            
            # Create lookup dictionaries for display names
            accounts_lookup = {}
            # Add bank accounts to lookup
            for account in from_source_account_records:
                accounts_lookup[account.get('id')] = f"{account.get('bank_name', '')}-{account.get('account_type', '')}"
            # Add contacts to lookup
            for contact in contact_records:
                accounts_lookup[contact.get('id')] = f"{contact.get('name', '')}-contact"
            
            categories_lookup = {}
            for category in category_records:
                categories_lookup[category.get('id')] = category.get('name', '')
            
            projects_lookup = {}
            for project in myproject_records:
                projects_lookup[project.get('id')] = project.get('nick_name', '')
            
            # Add display names to income_data
            income_data['from_source_account_display'] = accounts_lookup.get(income_data.get('from_source_account'), income_data.get('from_source_account'))
            income_data['category_display'] = categories_lookup.get(income_data.get('category'), income_data.get('category'))
            income_data['to_account_display'] = accounts_lookup.get(income_data.get('to_account'), income_data.get('to_account'))
            income_data['my_project_display'] = projects_lookup.get(income_data.get('my_project'), income_data.get('my_project'))
            
        else:
            print('error------',income)
            messages.error(request, 'Failed to retrieve data for income. Please check your connection and try again.', extra_tags='warning')
            return redirect('income')

        if request.method == "POST":
            form = IncomeFormEdit(request.POST, files=request.FILES, initial=income_data, 
                            contact_records=contact_records,
                            from_source_account_choice=from_source_account_records,
                            category_choice=category_records,
                            to_account_choice=to_account_records,
                            myproject_records=myproject_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                print("-json_data----",json_data)
                response = call_put_method(BASEURL, f'my_money/income/{pk}/', json_data, token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Income successfully updated.', extra_tags='success')
                    return redirect('income') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('income_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = IncomeFormEdit(initial=income_data,
                            from_source_account_choice=from_source_account_records,
                            contact_records=contact_records,
                            category_choice=category_records,
                            to_account_choice=to_account_records,
                            myproject_records=myproject_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('income_edit.html', {'form': form, 'income_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context = {
            'form': form
        }
        return render(request, 'income_edit.html', context)
    except Exception as error:
        return render(request, '500.html', {'error': error})

@custom_login_required
def income_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/income/{pk}/'
        income = call_delete_method(BASEURL, end_point,token)
        if income.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for income. Please try again.', extra_tags='warning')
            return redirect('income')
        else:
            messages.success(request, 'Successfully deleted data for income', extra_tags='success')
            return redirect('income')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def savingsgoal(request):
    try:
        token = request.session['user_token']


        online_account_response = call_get_method(BASEURL, 'my_money/only-my-bankaccount/', token)
        if online_account_response.status_code in [200,201]:
            online_account_records = online_account_response.json()
            # print(online_account_records)
        else:
            online_account_records = []
    

        physical_account_response = call_get_method(BASEURL, 'my_money/my-all-wallet/', token)
        if physical_account_response.status_code in [200,201]:
            physical_account_records = physical_account_response.json()
        else:
            physical_account_records = []
    

        form=SavingsGoalForm(online_account_choice=online_account_records,physical_account_choice=physical_account_records)
        endpoint = 'my_money/savingsgoal/'
        if request.method=="POST":
            form=SavingsGoalForm(request.POST,files = request.FILES,online_account_choice=online_account_records,physical_account_choice=physical_account_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('savingsgoal')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('savingsgoal_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'savingsgoal.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'savingsgoal.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def savingsgoal_edit(request,pk):
    # try:

        token = request.session['user_token']


        online_account_response = call_get_method(BASEURL, 'my_money/only-my-bankaccount/', token)
        if online_account_response.status_code in [200,201]:
            online_account_records = online_account_response.json()
            # print(online_account_records)
        else:
            online_account_records = []
    

        physical_account_response = call_get_method(BASEURL, 'my_money/my-all-wallet/', token)
        if physical_account_response.status_code in [200,201]:
            physical_account_records = physical_account_response.json()
        else:
            physical_account_records = []
    



        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        savingsgoal = call_get_method(BASEURL, f'my_money/savingsgoal/{pk}/',token)
        
        if savingsgoal.status_code in [200,201]:
            savingsgoal_data = savingsgoal.json()
        else:
            print('error------',savingsgoal)
            messages.error(request, 'Failed to retrieve data for savingsgoal. Please check your connection and try again.', extra_tags='warning')
            return redirect('savingsgoal')

        if request.method=="POST":
            form=SavingsGoalForm(request.POST,files = request.FILES, initial=savingsgoal_data,online_account_choice=online_account_records,physical_account_choice=physical_account_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/savingsgoal/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'savingsgoal successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('savingsgoal') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('savingsgoal_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = SavingsGoalForm(initial=savingsgoal_data,online_account_choice=online_account_records,physical_account_choice=physical_account_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('savingsgoal_edit.html', {'form': form, 'savingsgoal_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'savingsgoal_edit.html',context)
    # except Exception as error:
    #     return render(request,'500.html',{'error':error})


@custom_login_required
def savingsgoal_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/savingsgoal/{pk}/'
        savingsgoal = call_delete_method(BASEURL, end_point,token)
        if savingsgoal.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for savingsgoal. Please try again.', extra_tags='warning')
            return redirect('savingsgoal')
        else:
            messages.success(request, 'Successfully deleted data for savingsgoal', extra_tags='success')
            return redirect('savingsgoal')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def transaction(request):
    try:
        token = request.session['user_token']


        from_account_response = call_get_method(BASEURL, 'my_money/bankaccount/', token)
        if from_account_response.status_code in [200,201]:
            from_account_records = from_account_response.json()
        else:
            from_account_records = []
    

        to_account_response = call_get_method(BASEURL, 'my_money/bankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []
    

        form=TransactionForm(from_account_choice=from_account_records,to_account_choice=to_account_records)
        endpoint = 'my_money/transaction/'
        if request.method=="POST":
            form=TransactionForm(request.POST,files = request.FILES,from_account_choice=from_account_records,to_account_choice=to_account_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('transaction')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('transaction_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'transaction.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'transaction.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def transaction_edit(request,pk):
    try:

        token = request.session['user_token']


        from_account_response = call_get_method(BASEURL, 'my_money/bankaccount/', token)
        if from_account_response.status_code in [200,201]:
            from_account_records = from_account_response.json()
        else:
            from_account_records = []
    

        to_account_response = call_get_method(BASEURL, 'my_money/bankaccount/', token)
        if to_account_response.status_code in [200,201]:
            to_account_records = to_account_response.json()
        else:
            to_account_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        transaction = call_get_method(BASEURL, f'my_money/transaction/{pk}/',token)
        
        if transaction.status_code in [200,201]:
            transaction_data = transaction.json()
        else:
            print('error------',transaction)
            messages.error(request, 'Failed to retrieve data for transaction. Please check your connection and try again.', extra_tags='warning')
            return redirect('transaction')

        if request.method=="POST":
            form=TransactionForm(request.POST,files = request.FILES, initial=transaction_data,from_account_choice=from_account_records,to_account_choice=to_account_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/transaction/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'transaction successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('transaction') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('transaction_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = TransactionForm(initial=transaction_data,from_account_choice=from_account_records,to_account_choice=to_account_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('transaction_edit.html', {'form': form, 'transaction_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'transaction_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def transaction_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/transaction/{pk}/'
        transaction = call_delete_method(BASEURL, end_point,token)
        if transaction.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for transaction. Please try again.', extra_tags='warning')
            return redirect('transaction')
        else:
            messages.success(request, 'Successfully deleted data for transaction', extra_tags='success')
            return redirect('transaction')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def expensevirtual(request):
    try:
        token = request.session['user_token']


        expense_response = call_get_method(BASEURL, 'my_money/expense/', token)
        if expense_response.status_code in [200,201]:
            expense_records = expense_response.json()
        else:
            expense_records = []
    

        form=ExpensevirtualForm(expense_choice=expense_records)
        endpoint = 'my_money/expensevirtual/'
        if request.method=="POST":
            form=ExpensevirtualForm(request.POST,files = request.FILES,expense_choice=expense_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('expensevirtual')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('expensevirtual_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'expensevirtual.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'expensevirtual.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def expensevirtual_edit(request,pk):
    try:

        token = request.session['user_token']


        expense_response = call_get_method(BASEURL, 'my_money/expense/', token)
        if expense_response.status_code in [200,201]:
            expense_records = expense_response.json()
        else:
            expense_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        expensevirtual = call_get_method(BASEURL, f'my_money/expensevirtual/{pk}/',token)
        
        if expensevirtual.status_code in [200,201]:
            expensevirtual_data = expensevirtual.json()
        else:
            print('error------',expensevirtual)
            messages.error(request, 'Failed to retrieve data for expensevirtual. Please check your connection and try again.', extra_tags='warning')
            return redirect('expensevirtual')

        if request.method=="POST":
            form=ExpensevirtualForm(request.POST,files = request.FILES, initial=expensevirtual_data,expense_choice=expense_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/expensevirtual/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'expensevirtual successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('expensevirtual') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('expensevirtual_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = ExpensevirtualForm(initial=expensevirtual_data,expense_choice=expense_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('expensevirtual_edit.html', {'form': form, 'expensevirtual_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'expensevirtual_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def expensevirtual_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/expensevirtual/{pk}/'
        expensevirtual = call_delete_method(BASEURL, end_point,token)
        if expensevirtual.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for expensevirtual. Please try again.', extra_tags='warning')
            return redirect('expensevirtual')
        else:
            messages.success(request, 'Successfully deleted data for expensevirtual', extra_tags='success')
            return redirect('expensevirtual')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def incomevirtual(request):
    try:
        token = request.session['user_token']


        income_response = call_get_method(BASEURL, 'my_money/income/', token)
        if income_response.status_code in [200,201]:
            income_records = income_response.json()
        else:
            income_records = []
    

        form=IncomevirtualForm(income_choice=income_records)
        endpoint = 'my_money/incomevirtual/'
        if request.method=="POST":
            form=IncomevirtualForm(request.POST,files = request.FILES,income_choice=income_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('incomevirtual')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('incomevirtual_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'incomevirtual.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'incomevirtual.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def incomevirtual_edit(request,pk):
    try:

        token = request.session['user_token']


        income_response = call_get_method(BASEURL, 'my_money/income/', token)
        if income_response.status_code in [200,201]:
            income_records = income_response.json()
        else:
            income_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        incomevirtual = call_get_method(BASEURL, f'my_money/incomevirtual/{pk}/',token)
        
        if incomevirtual.status_code in [200,201]:
            incomevirtual_data = incomevirtual.json()
        else:
            print('error------',incomevirtual)
            messages.error(request, 'Failed to retrieve data for incomevirtual. Please check your connection and try again.', extra_tags='warning')
            return redirect('incomevirtual')

        if request.method=="POST":
            form=IncomevirtualForm(request.POST,files = request.FILES, initial=incomevirtual_data,income_choice=income_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/incomevirtual/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'incomevirtual successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('incomevirtual') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('incomevirtual_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = IncomevirtualForm(initial=incomevirtual_data,income_choice=income_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('incomevirtual_edit.html', {'form': form, 'incomevirtual_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'incomevirtual_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def incomevirtual_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/incomevirtual/{pk}/'
        incomevirtual = call_delete_method(BASEURL, end_point,token)
        if incomevirtual.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for incomevirtual. Please try again.', extra_tags='warning')
            return redirect('incomevirtual')
        else:
            messages.success(request, 'Successfully deleted data for incomevirtual', extra_tags='success')
            return redirect('incomevirtual')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def contribution(request):
    try:
        token = request.session['user_token']


        savings_goal_response = call_get_method(BASEURL, 'my_money/savingsgoal/', token)
        if savings_goal_response.status_code in [200,201]:
            savings_goal_records = savings_goal_response.json()
        else:
            savings_goal_records = []
    

        from_account_response = call_get_method(BASEURL, 'my_money/bankaccount/', token)
        if from_account_response.status_code in [200,201]:
            from_account_records = from_account_response.json()
        else:
            from_account_records = []
    

        form=ContributionForm(savings_goal_choice=savings_goal_records,from_account_choice=from_account_records)
        endpoint = 'my_money/contribution/'
        if request.method=="POST":
            form=ContributionForm(request.POST,files = request.FILES,savings_goal_choice=savings_goal_records,from_account_choice=from_account_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('contribution')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('contribution_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'contribution.html', {
                    'form': form,
                    'records': records,
                    

                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
           
        }
        return render(request,'contribution.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def contribution_edit(request,pk):
    try:

        token = request.session['user_token']


        savings_goal_response = call_get_method(BASEURL, 'my_money/savingsgoal/', token)
        if savings_goal_response.status_code in [200,201]:
            savings_goal_records = savings_goal_response.json()
        else:
            savings_goal_records = []
    

        from_account_response = call_get_method(BASEURL, 'my_money/bankaccount/', token)
        if from_account_response.status_code in [200,201]:
            from_account_records = from_account_response.json()
        else:
            from_account_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        contribution = call_get_method(BASEURL, f'my_money/contribution/{pk}/',token)
        
        if contribution.status_code in [200,201]:
            contribution_data = contribution.json()
        else:
            print('error------',contribution)
            messages.error(request, 'Failed to retrieve data for contribution. Please check your connection and try again.', extra_tags='warning')
            return redirect('contribution')

        if request.method=="POST":
            form=ContributionForm(request.POST,files = request.FILES, initial=contribution_data,savings_goal_choice=savings_goal_records,from_account_choice=from_account_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/contribution/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'contribution successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('contribution') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('contribution_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = ContributionForm(initial=contribution_data,savings_goal_choice=savings_goal_records,from_account_choice=from_account_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('contribution_edit.html', {'form': form, 'contribution_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'contribution_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def contribution_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/contribution/{pk}/'
        contribution = call_delete_method(BASEURL, end_point,token)
        if contribution.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for contribution. Please try again.', extra_tags='warning')
            return redirect('contribution')
        else:
            messages.success(request, 'Successfully deleted data for contribution', extra_tags='success')
            return redirect('contribution')

    except Exception as error:
        return render(request,'500.html',{'error':error})

def myaccounts(request):
    return render(request,'myaccount.html')

def mywallet(request):
    return render(request,'mywallet.html')


# create and view table function
@custom_login_required
def wallet_locker(request):
    try:
        token = request.session['user_token']
        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
        form=LockerForm()
        endpoint = 'my_money/wallet_locker/'
        if request.method=="POST":
            form=LockerForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                Output['wallet_type']='locker'
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('wallet_locker')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('wallet_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'wallet_locker.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records,
        }
        return render(request,'wallet_locker.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def wallet_locker_edit(request,pk):
    try:

        token = request.session['user_token']

        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        wallet = call_get_method(BASEURL, f'my_money/wallet_locker/{pk}/',token)
        
        if wallet.status_code in [200,201]:
            wallet_data = wallet.json()
        else:
            print('error------',wallet)
            messages.error(request, 'Failed to retrieve data for wallet. Please check your connection and try again.', extra_tags='warning')
            return redirect('wallet_locker')

        if request.method=="POST":
            form=LockerForm(request.POST,files = request.FILES, initial=wallet_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/wallet_locker/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'wallet successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('wallet_locker') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('wallet_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = LockerForm(initial=wallet_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('wallet_locker_edit.html', {'form': form, 'wallet_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'wallet_locker_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def wallet_locker_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/wallet_locker/{pk}/'
        wallet = call_delete_method(BASEURL, end_point,token)
        if wallet.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for wallet. Please try again.', extra_tags='warning')
            return redirect('wallet_locker')
        else:
            messages.success(request, 'Successfully deleted data for wallet', extra_tags='success')
            return redirect('wallet_locker')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function

# create and view table function
@custom_login_required
def wallet_piggy(request):
    try:
        token = request.session['user_token']
        account_response = call_get_method(BASEURL, 'my_money/allbankaccount/', token)
        if account_response.status_code in [200,201]:
            account_records = account_response.json()
        else:
            account_records = []
        form=PiggyForm()
        endpoint = 'my_money/wallet_piggy/'
        if request.method=="POST":
            form=PiggyForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                Output['wallet_type']='piggybank'
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('wallet_piggy')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('wallet_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'wallet_piggy.html', {
                    'form': form,
                    'records': records,
                    'account_records':account_records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
            'account_records':account_records
        }
        return render(request,'wallet.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def wallet_piggy_edit(request,pk):
    try:

        token = request.session['user_token']

        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        wallet = call_get_method(BASEURL, f'my_money/wallet_piggy/{pk}/',token)
        
        if wallet.status_code in [200,201]:
            wallet_data = wallet.json()
        else:
            print('error------',wallet)
            messages.error(request, 'Failed to retrieve data for wallet. Please check your connection and try again.', extra_tags='warning')
            return redirect('wallet_piggy')

        if request.method=="POST":
            form=PiggyForm(request.POST,files = request.FILES, initial=wallet_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/wallet_piggy/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'wallet successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('wallet_piggy') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('wallet_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = PiggyForm(initial=wallet_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('wallet_piggy_edit.html', {'form': form, 'wallet_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'wallet_piggy_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def wallet_piggy_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/wallet_piggy/{pk}/'
        wallet = call_delete_method(BASEURL, end_point,token)
        if wallet.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for wallet. Please try again.', extra_tags='warning')
            return redirect('wallet_piggy')
        else:
            messages.success(request, 'Successfully deleted data for wallet', extra_tags='success')
            return redirect('wallet_piggy')

    except Exception as error:
        return render(request,'500.html',{'error':error})


# create and view table function
@custom_login_required
def allentry(request):
    try:
        token = request.session['user_token']
        form=MyProjectForm()
        endpoint = 'my_money/all-entries/'
        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'accountentry.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
        }
        return render(request,'accountentry.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# create and view table function
@custom_login_required
def acc_entry(request,id):
    try:
        token = request.session['user_token']
        form=MyProjectForm()    
        endpoint = f'my_money/acc_entries/{id}/'
        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'single_accountentry.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[],
        }
        return render(request,'single_accountentry.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})
    
@custom_login_required
def transaction_income(request,id,code):
    token = request.session['user_token']
    records_response = call_get_method(BASEURL,f'my_money/trans_inc/{id}/{code}/',token)
    if records_response.status_code in [200,201]:
        records = records_response.json()
        print("record",records)
        return render(request, 'trans_inc.html', {
            'record': records,
            "file_base_url": settings.FILE_BASE_URL,
        })
        
        
@custom_login_required
def transaction_expense(request,id,code):
    token = request.session['user_token']
    records_response = call_get_method(BASEURL,f'my_money/trans_exp/{id}/{code}/',token)
    if records_response.status_code in [200,201]:
        records = records_response.json()
        print("record",records)
        return render(request, 'trans_exp.html', {
            'record': records,
            "file_base_url": settings.FILE_BASE_URL,
        })
        
 
def deposite(request):
    if request.method == 'POST':
        token = request.session['user_token']
        endpoint = 'my_money/Depositebank/'
        print("all value",request.POST)

        Output={
            'from_account':request.POST.get('from_account'),
            'to_account':request.POST.get('to_account'),
            'amount':request.POST.get('amount'),
        }
        print("Output",Output)
        json_data=json.dumps(Output)
        response = call_post_with_method(BASEURL,endpoint,json_data,token)
        if response.status_code in [200,201]:
            print("error",response)
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'success': True})
            messages.success(request, 'Data Successfully Saved', extra_tags="success")
        return redirect('myaccounts')