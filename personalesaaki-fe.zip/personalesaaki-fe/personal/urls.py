from django.urls import path,include
from .views import *
urlpatterns = [
    
	path("contactcategory/", contactcategory, name="contactcategory"),
	path("contactcategory_edit/<pk>/", contactcategory_edit, name="contactcategory_edit"),
	path("contactcategory_delete/<pk>/", contactcategory_delete, name="contactcategory_delete"),
	path("documenttype/", documenttype, name="documenttype"),
	path("documenttype_edit/<pk>/", documenttype_edit, name="documenttype_edit"),
	path("documenttype_delete/<pk>/", documenttype_delete, name="documenttype_delete"),
	path("contact/", contact, name="contact"),
	path("contact_edit/<pk>/", contact_edit, name="contact_edit"),
	path("contact_delete/<pk>/", contact_delete, name="contact_delete"),
	path("identitydocument/", identitydocument, name="identitydocument"),
	path("identitydocument_edit/<pk>/", identitydocument_edit, name="identitydocument_edit"),
	path("identitydocument_delete/<pk>/", identitydocument_delete, name="identitydocument_delete"),
	path("personalinfo/", personalinfo, name="personalinfo"),
	path("personalinfo_edit/<pk>/", personalinfo_edit, name="personalinfo_edit"),
	path("personalinfo_delete/<pk>/", personalinfo_delete, name="personalinfo_delete"),
	path("myproject/", myproject, name="myproject"),
	path("myproject_edit/<pk>/", myproject_edit, name="myproject_edit"),
	path("myproject_delete/<pk>/", myproject_delete, name="myproject_delete"),
 
	path("myproject_detail/<id>/", myproject_detail, name="myproject_detail"),
	path("contact_import_vcf", contact_import_vcf, name="contact_import_vcf"),
	path("notes/", notes, name="notes"),
    
]