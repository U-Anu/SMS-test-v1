from django import forms
from .models import *
from django.forms import BaseFormSet,DateInput, DateTimeInput, TimeInput, CheckboxInput, Textarea, TextInput
# from mainapp.forms import GenericModelForm
from django.core.validators import MinValueValidator
from django.core.validators import FileExtensionValidator, MaxValueValidator
from django.utils.safestring import mark_safe
from django.shortcuts import resolve_url

class ForeignKeySelectWithAdd(forms.Select):
    """
    Renders a <select> plus a small '+' button that links to the create page.
    Usage: widget=ForeignKeySelectWithAdd(add_url='company_create')  # URL name or absolute URL
    """
    def __init__(self, add_url=None, open_in_popup=False, *args, **kwargs):
        self.add_url = add_url
        self.open_in_popup = open_in_popup
        super().__init__(*args, **kwargs)

    def render(self, name, value, attrs=None, renderer=None):
        select_html = super().render(name, value, attrs, renderer)
        href = resolve_url(self.add_url) if self.add_url else "#"

        if self.open_in_popup:
            # Open a small popup like Django admin; no template changes required
            add_button_html = (
                f'<a href="{href}" onclick="window.open(this.href, \'popup\', '
                f'\'width=900,height=700,resizable,scrollbars\'); return false;" '
                f'class="btn btn-success btn-sm ml-2" title="Add new">+</a>'
            )
        else:
            add_button_html = (
                f'<a href="{href}" target="_blank" '
                f'class="btn btn-success btn-sm ml-2" title="Add new">+</a>'
            )

        # Wrap neatly; keep your existing form-control on the <select>
        html = (
            '<div style="display:flex; align-items:center; gap:.5rem;">'
            f'{select_html}{add_button_html}'
            '</div>'
        )
        return mark_safe(html)


class ContactCategoryForm(forms.Form):
	name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))


class DocumentTypeForm(forms.Form):
	name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))


class ContactForm(forms.Form):
	name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	category = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="contactcategory", open_in_popup=True,attrs={"class": "form-control"}))
	phone = forms.CharField(max_length=20, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	email = forms.EmailField(required=False, widget=forms.TextInput(attrs={"type": "email","class": "form-control"}))
	address = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	def __init__(self, *args, **kwargs):
		category_list = kwargs.pop('category_choice', [])
		initial_data = kwargs.get("initial", {})
		selected_category = initial_data.get('category', '')
		super().__init__(*args, **kwargs)
		self.fields['category'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('name', '')) for record in category_list]
		if selected_category:
			self.fields['category'].initial = selected_category



class IdentityDocumentForm(forms.Form):
	name = forms.CharField(max_length=255, required=False, help_text="e.g. passport", widget=forms.TextInput(attrs={"class": "form-control"}))
	document_type = forms.ChoiceField(required=False, widget=ForeignKeySelectWithAdd(add_url="documenttype", open_in_popup=True,attrs={"class": "form-control"}))
	document_number = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	issue_date = forms.DateField(input_formats=['%Y-%m-%d'],required=False, widget=forms.DateInput(attrs={"type": "date","class": "form-control"}))
	expiry_date = forms.DateField(input_formats=['%Y-%m-%d'],required=False, widget=forms.DateInput(attrs={"type": "date","class": "form-control"}))
	file = forms.FileField(required=True,widget=forms.ClearableFileInput(attrs={"class": "form-control-file"}))
	notes = forms.CharField(required=False, widget=forms.Textarea(attrs={"class": "form-control"}))
	def __init__(self, *args, **kwargs):
		document_type_list = kwargs.pop('document_type_choice', [])
		initial_data = kwargs.get("initial", {})
		selected_document_type = initial_data.get('document_type', '')
		super().__init__(*args, **kwargs)
		self.fields['document_type'].choices = [('', '---select---')] + [(record.get('id', ''), record.get('name', '')) for record in document_type_list]
		if selected_document_type:
			self.fields['document_type'].initial = selected_document_type



class PersonalInfoForm(forms.Form):
	date_of_birth = forms.DateField(input_formats=['%Y-%m-%d'],required=False, widget=forms.DateInput(attrs={"type": "date","class": "form-control"}))
	gender = forms.ChoiceField(choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	marital_status = forms.ChoiceField(choices=[('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widowed', 'Widowed')], required=False,widget=forms.Select(attrs={"class": "form-control"}))
	nationality = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	national_id = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	passport_number = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
	address = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))


class myprojectForm(forms.Form):
	nick_name = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={"class": "form-control"}))
