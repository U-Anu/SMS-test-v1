from django.http import JsonResponse
from django.shortcuts import render, redirect
from .forms import *
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.forms import formset_factory
from django.forms import modelformset_factory
from mainapp.views import *
from django.template.loader import render_to_string

APP_NAME = __name__.split('.')[0]

BASEURL = settings.BASEURL


# create and view table function
@custom_login_required
def contactcategory(request):
    try:
        token = request.session['user_token']


        form=ContactCategoryForm()
        endpoint = 'personal/contactcategory/'
        if request.method=="POST":
            form=ContactCategoryForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('contactcategory')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('contactcategory_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'contactcategory.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'contactcategory.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def contactcategory_edit(request,pk):
    try:

        token = request.session['user_token']



        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        contactcategory = call_get_method(BASEURL, f'personal/contactcategory/{pk}/',token)
        
        if contactcategory.status_code in [200,201]:
            contactcategory_data = contactcategory.json()
        else:
            print('error------',contactcategory)
            messages.error(request, 'Failed to retrieve data for contactcategory. Please check your connection and try again.', extra_tags='warning')
            return redirect('contactcategory')

        if request.method=="POST":
            form=ContactCategoryForm(request.POST,files = request.FILES, initial=contactcategory_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'personal/contactcategory/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'contactcategory successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('contactcategory') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('contactcategory_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = ContactCategoryForm(initial=contactcategory_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('contactcategory_edit.html', {'form': form, 'contactcategory_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'contactcategory_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def contactcategory_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'personal/contactcategory/{pk}/'
        contactcategory = call_delete_method(BASEURL, end_point,token)
        if contactcategory.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for contactcategory. Please try again.', extra_tags='warning')
            return redirect('contactcategory')
        else:
            messages.success(request, 'Successfully deleted data for contactcategory', extra_tags='success')
            return redirect('contactcategory')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def documenttype(request):
    try:
        token = request.session['user_token']


        form=DocumentTypeForm()
        endpoint = 'personal/documenttype/'
        if request.method=="POST":
            form=DocumentTypeForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('documenttype')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('documenttype_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'documenttype.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'documenttype.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def documenttype_edit(request,pk):
    try:

        token = request.session['user_token']

        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        documenttype = call_get_method(BASEURL, f'personal/documenttype/{pk}/',token)
        
        if documenttype.status_code in [200,201]:
            documenttype_data = documenttype.json()
        else:
            print('error------',documenttype)
            messages.error(request, 'Failed to retrieve data for documenttype. Please check your connection and try again.', extra_tags='warning')
            return redirect('documenttype')

        if request.method=="POST":
            form=DocumentTypeForm(request.POST,files = request.FILES, initial=documenttype_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'personal/documenttype/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'documenttype successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('documenttype') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('documenttype_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = DocumentTypeForm(initial=documenttype_data,)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('documenttype_edit.html', {'form': form, 'documenttype_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'documenttype_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def documenttype_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'personal/documenttype/{pk}/'
        documenttype = call_delete_method(BASEURL, end_point,token)
        if documenttype.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for documenttype. Please try again.', extra_tags='warning')
            return redirect('documenttype')
        else:
            messages.success(request, 'Successfully deleted data for documenttype', extra_tags='success')
            return redirect('documenttype')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def contact(request):
    try:
        token = request.session['user_token']


        category_response = call_get_method(BASEURL, 'personal/contactcategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []
    

        form=ContactForm(category_choice=category_records)
        endpoint = 'personal/contact/'
        if request.method=="POST":
            form=ContactForm(request.POST,files = request.FILES,category_choice=category_records)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('contact')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('contact_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'contact.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'contact.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def contact_edit(request,pk):
    try:

        token = request.session['user_token']


        category_response = call_get_method(BASEURL, 'personal/contactcategory/', token)
        if category_response.status_code in [200,201]:
            category_records = category_response.json()
        else:
            category_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        contact = call_get_method(BASEURL, f'personal/contact/{pk}/',token)
        
        if contact.status_code in [200,201]:
            contact_data = contact.json()
        else:
            print('error------',contact)
            messages.error(request, 'Failed to retrieve data for contact. Please check your connection and try again.', extra_tags='warning')
            return redirect('contact')

        if request.method=="POST":
            form=ContactForm(request.POST,files = request.FILES, initial=contact_data,category_choice=category_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'personal/contact/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'contact successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('contact') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('contact_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = ContactForm(initial=contact_data,category_choice=category_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('contact_edit.html', {'form': form, 'contact_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'contact_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def contact_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'personal/contact/{pk}/'
        contact = call_delete_method(BASEURL, end_point,token)
        if contact.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for contact. Please try again.', extra_tags='warning')
            return redirect('contact')
        else:
            messages.success(request, 'Successfully deleted data for contact', extra_tags='success')
            return redirect('contact')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function
@custom_login_required
def identitydocument(request):
    try:
        token = request.session['user_token']


        document_type_response = call_get_method(BASEURL, 'personal/documenttype/', token)
        if document_type_response.status_code in [200,201]:
            document_type_records = document_type_response.json()
        else:
            document_type_records = []
    

        form=IdentityDocumentForm(document_type_choice=document_type_records)
        endpoint = 'personal/identitydocument/'
        if request.method=="POST":
            form=IdentityDocumentForm(request.POST,files = request.FILES,document_type_choice=document_type_records)
            if form.is_valid():
                Output = form.cleaned_data
                print("all data",Output)
                # print("all data",files)
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
             
                file=Output.pop('file')
                files=request.FILES.get('file')
                file={'files':files}
                response = call_post_with_file_method(BASEURL,endpoint,Output,token,files=file)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('identitydocument')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('identitydocument_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'identitydocument.html', {
                    'form': form,
                    'records': records,
                     "file_base_url": settings.FILE_BASE_URL,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'identitydocument.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})

# edit function
@custom_login_required
def identitydocument_edit(request,pk):
    try:

        token = request.session['user_token']


        document_type_response = call_get_method(BASEURL, 'personal/documenttype/', token)
        if document_type_response.status_code in [200,201]:
            document_type_records = document_type_response.json()
        else:
            document_type_records = []
    


        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        identitydocument = call_get_method(BASEURL, f'personal/identitydocument/{pk}/',token)
        
        if identitydocument.status_code in [200,201]:
            identitydocument_data = identitydocument.json()
        else:
            print('error------',identitydocument)
            messages.error(request, 'Failed to retrieve data for identitydocument. Please check your connection and try again.', extra_tags='warning')
            return redirect('identitydocument')

        if request.method=="POST":
            form=IdentityDocumentForm(request.POST,files = request.FILES, initial=identitydocument_data,document_type_choice=document_type_records)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'personal/identitydocument/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'identitydocument successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('identitydocument') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('identitydocument_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = IdentityDocumentForm(initial=identitydocument_data,document_type_choice=document_type_records)

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('identitydocument_edit.html', {'form': form, 'identitydocument_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'identitydocument_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def identitydocument_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'personal/identitydocument/{pk}/'
        identitydocument = call_delete_method(BASEURL, end_point,token)
        if identitydocument.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for identitydocument. Please try again.', extra_tags='warning')
            return redirect('identitydocument')
        else:
            messages.success(request, 'Successfully deleted data for identitydocument', extra_tags='success')
            return redirect('identitydocument')

    except Exception as error:
        return render(request,'500.html',{'error':error})
# create and view table function

@custom_login_required
def personalinfo(request):
    # try:
        token = request.session['user_token']
        form=PersonalInfoForm()
        endpoint = 'personal/personalinfo/'
        if request.method=="POST":
            form=PersonalInfoForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('personalinfo')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('personalinfo_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                if records:
                    create=False
                else:
                    create=True
                return render(request, 'personalinfo.html', {
                    'form': form,
                    'create':create,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'create':False,
            'records':[]
        }
        return render(request,'personalinfo.html',context)
# edit function
@custom_login_required
def personalinfo_edit(request,pk):
    try:

        token = request.session['user_token']
        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        personalinfo = call_get_method(BASEURL, f'personal/personalinfo/{pk}/',token)
        
        if personalinfo.status_code in [200,201]:
            personalinfo_data = personalinfo.json()
        else:
            print('error------',personalinfo)
            messages.error(request, 'Failed to retrieve data for personalinfo. Please check your connection and try again.', extra_tags='warning')
            return redirect('personalinfo')

        if request.method=="POST":
            form=PersonalInfoForm(request.POST,files = request.FILES, initial=personalinfo_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'personal/personalinfo/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'personalinfo successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('personalinfo') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('personalinfo_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = PersonalInfoForm(initial=personalinfo_data,)
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('personalinfo_edit.html', {'form': form, 'personalinfo_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'personalinfo_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def personalinfo_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'personal/personalinfo/{pk}/'
        personalinfo = call_delete_method(BASEURL, end_point,token)
        if personalinfo.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for personalinfo. Please try again.', extra_tags='warning')
            return redirect('personalinfo')
        else:
            messages.success(request, 'Successfully deleted data for personalinfo', extra_tags='success')
            return redirect('personalinfo')

    except Exception as error:
        return render(request,'500.html',{'error':error})

@custom_login_required
def myproject(request):
    # try:
        token = request.session['user_token']
        form=myprojectForm()
        endpoint = 'my_money/myproject/'
        if request.method=="POST":
            form=myprojectForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('myproject')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('myproject_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                return render(request, 'myproject.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'myproject.html',context)
# edit function
    # except Exception as error:
    #     return render(request,'500.html',{'error':error})

@custom_login_required
def myproject_edit(request,pk):
    try:

        token = request.session['user_token']
        mode = request.GET.get('mode', 'edit')  # default to edit if not provided
        myproject = call_get_method(BASEURL, f'my_money/myproject/{pk}/',token)
        if myproject.status_code in [200,201]:
            myproject_data = myproject.json()
        else:
            print('error------',myproject)
            messages.error(request, 'Failed to retrieve data for myproject. Please check your connection and try again.', extra_tags='warning')
            return redirect('myproject')
        if request.method=="POST":
            form=myprojectForm(request.POST,files = request.FILES, initial=myproject_data,)
            if form.is_valid():
                updated_data = form.cleaned_data
                updated_data['id'] = pk
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, (forms.DateField, forms.DateTimeField, forms.DecimalField, forms.TimeField)):
                        if updated_data.get(field_name):
                            updated_data[field_name] = request.POST.get(field_name)

                # Serialize the updated data as JSON
                json_data = json.dumps(updated_data)
                response = call_put_method(BASEURL, f'my_money/myproject/{pk}/', json_data,token)

                if response.status_code in [200,201]: 
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'myproject successfully updated.', extra_tags='success')
                    # messages.success(request, 'Your data has been successfully saved', extra_tags='success')
                    return redirect('myproject') 
                else:
                    error_message = response.json()
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': error_message})
                    messages.error(request, f"Oops..! {error_message}", extra_tags='warning')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    html = render_to_string('myproject_edit.html', {'form': form,'mode': mode}, request=request)
                    return JsonResponse({'success': False, 'formHtml': html})
                messages.error(request, "Form validation failed.", extra_tags='danger')
                print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        else:
            form = myprojectForm(initial=myproject_data,)
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string('myproject_edit.html', {'form': form, 'myproject_id': pk,'mode': mode}, request=request)
            return HttpResponse(html)

        context={
            'form':form
        }
        return render(request,'myproject_edit.html',context)
    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def myproject_delete(request,pk):
    try:
        token = request.session['user_token']
        end_point = f'my_money/myproject/{pk}/'
        myproject = call_delete_method(BASEURL, end_point,token)
        if myproject.status_code in [200,201]:
            messages.error(request, 'Failed to delete data for myproject. Please try again.', extra_tags='warning')
            return redirect('myproject')
        else:
            messages.success(request, 'Successfully deleted data for myproject', extra_tags='success')
            return redirect('myproject')

    except Exception as error:
        return render(request,'500.html',{'error':error})


@custom_login_required
def myproject_detail(request,id):
    # try:
        token = request.session['user_token']
        form=myprojectForm()
        endpoint = f'my_money/myproject_detail/{id}'
        if request.method=="POST":
            form=myprojectForm(request.POST,files = request.FILES,)
            if form.is_valid():
                Output = form.cleaned_data
                for field_name, field in form.fields.items():
                    if isinstance(field.widget, forms.DateInput) or isinstance(field, forms.DateField) or isinstance(field, forms.DateTimeField) or isinstance(field, forms.DecimalField) or isinstance(field, forms.TimeField):
                        if Output[field_name]:
                            del Output[field_name]
                            Output[field_name] = request.POST.get(field_name)
                json_data=json.dumps(Output)
                response = call_post_with_method(BASEURL,endpoint,json_data,token)
                if response.status_code in [200,201]:
                    print("error",response)
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': True})
                    messages.success(request, 'Data Successfully Saved', extra_tags="success")
                    return redirect('myproject')

                else:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'success': False, 'error': response.json()})
                    messages.error(request, 'Error saving data', extra_tags='danger')
        else:
            print('errorss',form.errors)

            # AJAX request with invalid form
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                html = render_to_string('myproject_edit.html', {'form': form}, request=request)
                return JsonResponse({'success': False, 'formHtml': html})
            # non-AJAX fallback — fall through to render below

        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                print(records)
                return render(request, 'myproject_detail.html', {
                    'form': form,
                    'records': records,
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
        context={
            'form':form,
            'records':[]
        }
        return render(request,'myproject_detail.html',context)
# edit function
    # except Exception as error:
    #     return render(request,'500.html',{'error':error})
    
def contact_import_vcf(request):
        if request.method=="POST":
            token = request.session['user_token']
            endpoint = 'contact/contact/'
            files=request.FILES.get('vcf_file')
            file={'vcard_file':files}
            Output={
                
            }
            response = call_post_with_file_method(BASEURL,endpoint,Output,token,files=file)
            if response.status_code in [200,201]:
                print("error",response)
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': True})
                messages.success(request, 'Data Successfully Saved', extra_tags="success")
                return redirect('contact')

            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': response.json()})
                messages.error(request, 'Error saving data', extra_tags='danger')
                return redirect('contact')
        else:
            print('errorss',)

def notes(request):    
    try:
        if request.method=="POST":
            token = request.session['user_token']
            endpoint = 'personal/notes/'
            notes=request.POST.get('noteContent')
            title=request.POST.get('title')
            
            Output={
                'notes':notes,
                'title':title,
            }
            print("output",Output)
            json_data=json.dumps(Output)
            response = call_post_with_method(BASEURL,endpoint,json_data,token)
            if response.status_code in [200,201]:
                print("error",response)
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': True})
                messages.success(request, 'Data Successfully Saved', extra_tags="success")
                return redirect('notes')

            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': response.json()})
                messages.error(request, 'Error saving data', extra_tags='danger')
        token = request.session['user_token']
        endpoint = 'personal/notes/'
        try:
            # getting data from backend
            records_response = call_get_method(BASEURL,endpoint,token)
            if records_response.status_code in [200,201]:
                records = records_response.json()
                print("records",records.get('record'))
                return render(request, 'notes.html', {
                    'records': records.get('record'),
                })
            else:
                messages.error(request, f"Failed to fetch records. {records_response.json()}", extra_tags="warning")

        except Exception as e:
            print("An error occurred: Expecting value: line 1 column 1 (char 0)")
            print('===record==',e)
        context={
            'records':[]
        }
        return render(request,'notes.html',context)

    except Exception as error:
        return render(request,'500.html',{'error':error})          