from django.urls import path

from .views import *

urlpatterns = [
    path("",login, name="login"),
    path("signup/",signup, name="signup"),
    path('logout/', user_logout, name='logout'),
    path("base_dashboard/",base_dashboard, name="base_dashboard"),
    path("create-order/", create_razorpay_order, name="create_razorpay_order"),
    path('terms-conditions/', terms_conditions_view, name='terms_conditions'),
    path('privacy-policy/', privacy_policy_view, name='privacy_policy'),
    path('shipping-policy/', shipping_policy_view, name='shipping_policy'),
    path('contact-us/',contact_us_view, name='contact_us'),

]