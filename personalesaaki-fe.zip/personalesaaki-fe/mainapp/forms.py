from django import forms
from django.core.validators import MinValueValidator
from django.core.validators import FileExtensionValidator, MaxValueValidator
from .models import *