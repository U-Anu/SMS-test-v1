from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from .serializers import MpesaPaymentSerializer

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
import uuid

from paymentgateway.models import PaymentDetail, PaymentGateway
from .serializers import MpesaPaymentSerializer
from mpesapayment.mpesa_payments import (
    mpesa_stk_push,
)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def mpesa_api_payment(request):
    serializer = MpesaPaymentSerializer(data=request.data)

    if serializer.is_valid():
        phone = serializer.validated_data["phone"]
        amount = serializer.validated_data["amount"]
        amount_float = float(amount)
        description = "Order Payment"

        payment_response = mpesa_stk_push(amount_float, phone, description)
        print("Mpesa Response:", payment_response)

        if payment_response and payment_response.get("CheckoutRequestID"):
            payment_order_id = str(uuid.uuid4())[:8].upper()
            mpesa_gateway, _ = PaymentGateway.objects.get_or_create(name="Mpesa")

            PaymentDetail.objects.create(
                payment_order_id=payment_order_id,
                amount=amount,
                payment_mode="WALLET",
                status="PENDING",
                payment_gateway=mpesa_gateway,
                created_time=timezone.now(),
            )

            return Response(
                {
                    "success": True,
                    "message": f"Payment initiated successfully for {phone}",
                    "amount": amount,
                    "payment_order_id": payment_order_id,
                },
                status=status.HTTP_200_OK,
            )
        else:
            return Response(
                {"success": False, "message": "Mpesa payment failed or not completed."},
                status=status.HTTP_400_BAD_REQUEST,
            )

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# @api_view(["POST"])
# @permission_classes([IsAuthenticated])
# def mpesa_api_payment(request):
#     serializer = MpesaPaymentSerializer(data=request.data)

#     if serializer.is_valid():
#         phone = serializer.validated_data["phone"]
#         amount = serializer.validated_data["amount"]
#         # Simulate payment success
#         return Response(
#             {
#                 "success": True,
#                 "message": f"Payment successful for {phone}",
#                 "amount": amount,
#             },
#             status=status.HTTP_200_OK,
#         )
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
