from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone
from paymentgateway.models import PaymentDetail, PaymentGateway
import uuid
from mpesapayment.mpesa_payments import mpesa_stk_push
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt  # Remove in production
def mpesa_payment(request, selected_address=None):
    if request.method == "POST":
        print("Payment m -pesa is working")
        phone = request.POST.get("phone")
        amount = request.POST.get("amount")

        if phone and amount:
            description = "Order Payment"
            print("Mpesa Payment Called")
            print("Amount:", amount, "Phone:", phone)

            # Call Mpesa STK push
            payment_response = mpesa_stk_push(amount, phone, description)
            print("Mpesa Response:", payment_response)

            if payment_response and payment_response.get("CheckoutRequestID"):
                payment_order_id = str(uuid.uuid4())[:8].upper()
                mpesa_gateway, _ = PaymentGateway.objects.get_or_create(name="Mpesa")

                PaymentDetail.objects.create(
                    payment_order_id=payment_order_id,
                    amount=amount,
                    payment_mode="WALLET",
                    status="PENDING",
                    payment_gateway=mpesa_gateway,
                    created_time=timezone.now(),
                )

                return render(
                    request,
                    "mpesa.html",
                    {
                        "success": True,
                        "amount": amount,
                        "phone": phone,
                        "redirect_url": reverse("home"),
                    },
                )
        else:
            # Missing phone or amount
            return render(
                request,
                "mpesa.html",
                {"error": "Please enter both phone and amount."},
            )

    # GET request
    return render(request, "mpesa.html")


# from django.shortcuts import render
# from django.urls import reverse
# from django.utils import timezone
# from .forms import PaymentDetailForm
# from paymentgateway.models import (
#     PaymentDetail,
#     PaymentGateway,
#     CountryPaymentGatewayMapping,
# )
# import uuid
# from mpesapayment.mpesa_payments import mpesa_stk_push
# from django.views.decorators.csrf import csrf_exempt


# @csrf_exempt  # Remove in production
# def mpesa_payment(request, selected_address=None):
#     form = PaymentDetailForm(request.POST or None)

#     if request.method == "POST":
#         method = request.POST.get("gateway_code")
#         if method and method.lower() == "mpesa" and form.is_valid():
#             print("Payment called")
#             amount = form.cleaned_data["amount"]
#             phone = request.POST.get("phone")
#             description = "Order Payment"

#             print("Mpesa Payment Called")
#             print("Amount:", amount, "Phone:", phone)

#             # Call Mpesa STK push
#             payment_response = mpesa_stk_push(amount, phone, description)
#             print("Mpesa Response:", payment_response)

#             if payment_response and payment_response.get("CheckoutRequestID"):
#                 payment_order_id = str(uuid.uuid4())[:8].upper()
#                 mpesa_gateway, _ = PaymentGateway.objects.get_or_create(name="Mpesa")

#                 PaymentDetail.objects.create(
#                     payment_order_id=payment_order_id,
#                     amount=amount,
#                     payment_mode="WALLET",
#                     status="PENDING",
#                     payment_gateway=mpesa_gateway,
#                     created_time=timezone.now(),
#                 )

#                 return render(
#                     request,
#                     "frontend/home.html",
#                     {
#                         "form": PaymentDetailForm(),
#                         "total": amount,
#                         "methods": PaymentGateway.objects.all(),
#                         "selected_address": selected_address,
#                         "is_buy_now": False,
#                         "success": True,
#                         "redirect_url": reverse("my_account"),
#                     },
#                 )

#     return render(
#         request,
#         "frontend/home.html",
#         {
#             "form": form,
#             "total": 0,
#             "methods": PaymentGateway.objects.all(),
#             "selected_address": selected_address,
#             "is_buy_now": request.session.get("buy_now_flag", False),
#         },
#     )
