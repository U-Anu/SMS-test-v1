from django.db import models


# Create your models here.
class MpesaSTKPushPayment(models.Model):
    merchantRequestID = models.CharField(max_length=250)
    checkoutRequestID = models.CharField(max_length=250)
    resultDesc = models.CharField(max_length=100)
    amount = models.PositiveBigIntegerField()
    mpesaReceiptNumber = models.CharField(max_length=15)
    transactionDate = models.PositiveBigIntegerField()
    phoneNumber = models.PositiveBigIntegerField()


class MpesaC2BPayment(models.Model):
    first_name = models.CharField(max_length=15)
    last_name = models.CharField(max_length=15)
    middle_name = models.CharField(max_length=15)
    description = models.CharField(max_length=100)
    phone_number = models.IntegerField()
    amount = models.IntegerField()
    reference = models.CharField(max_length=15)
    organization_balance = models.IntegerField()
    transaction_type = models.CharField(max_length=15)


class MpesaB2CPayment(models.Model):
    conversationId = models.CharField(max_length=50)
    originatorConversationId = models.CharField(max_length=250)
    resultDesc = models.CharField(max_length=100)
    resultType = models.IntegerField()
    resultCode = models.IntegerField()
    transactionID = models.CharField(max_length=25)
    transactionReceipt = models.CharField(max_length=15)
    transactionAmount = models.IntegerField()
    transactionCompletedDateTime = models.CharField(max_length=25)
    receiverPartyPublicName = models.CharField(max_length=55)
