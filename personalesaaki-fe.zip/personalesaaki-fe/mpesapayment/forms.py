from django import forms
from paymentgateway.models import PaymentDetail


class PaymentDetailForm(forms.ModelForm):
    class Meta:
        model = PaymentDetail
        fields = ["amount", "payment_mode"]
        widgets = {
            "amount": forms.NumberInput(
                attrs={"placeholder": "Enter Amount", "class": "form-control"}
            ),
            "payment_mode": forms.Select(attrs={"class": "form-control"}),
        }
