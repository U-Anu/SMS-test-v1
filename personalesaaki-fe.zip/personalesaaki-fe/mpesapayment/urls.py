from django.urls import path
from .views import mpesa_payment
from .api_view import mpesa_api_payment

app_name = "mpesapayment"

urlpatterns = [
    path("mpesa/", mpesa_payment, name="mpesa_payment"),
    path("api/", mpesa_api_payment, name="mpesa_api_payment"),
]
