import json
import uuid
from django.shortcuts import render
from django.conf import settings
from django.utils import timezone

from mainapp.api_call import call_post_with_method
from mainapp.views import BASEURL
from .forms import PaymentForm
import razorpay
from django.shortcuts import render, redirect
from django.conf import settings
import uuid

# Initialize Razorpay client
client = razorpay.Client(
    auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_API_SECRET_KEY)
)


def razorpay_payment(request):
    if request.method == "POST":
        form_data = request.POST 
        # Convert to dict if you want
        data = form_data.dict()

        print("All form data:", data)
        # Get form data directly from POST
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone_no = request.POST.get("phone_no")
        amount = request.POST.get("amount")
        ticket = request.POST.get("ticket")
        project_id = request.POST.get("project_id")

        # Validate required fields (simple example)
        # if not all([name, email, phone_no, amount, ticket, project_id]):
        #     return render(request, "payment_error.html", {"errors": "All fields are required."})

        # Convert amount to paisa
        
        try:
            amount_in_paisa = int(float(amount) * 100)
        except ValueError:
            return render(request, "payment_error.html", {"errors": "Invalid amount."})

        # Create Razorpay Order
        order = client.order.create({
            "amount": amount_in_paisa,
            "currency": "INR",
            "payment_capture": 1
        })
        
        token = request.session['user_token']
        endpoint='RaizorPayment/razorpay_response/'
        Output={
            'ticket':"",
            'request':data
        }
        json_data=json.dumps(Output)
        response = call_post_with_method(BASEURL,endpoint,json_data,token)
        if response.status_code in [200,201]:
            print("error",response)
        print("error",response.json())
        # Custom order ID
        custom_order_id = str(uuid.uuid4())[:8].upper()

        print("======================= Razorpay payment view =======================")
        print("name:", name)
        print("email:", email)
        print("phone_no:", phone_no)
        print("amount:", amount)
        print("ticket:", ticket)
        print("project_id:", project_id)

        # Context for Razorpay checkout page
        context = {
            "name": name,
            "email": email,
            "phone_no": phone_no,
            "amount": amount,
            "razorpay_order_id": order["id"],
            "custom_order_id": custom_order_id,
            "razorpay_key": settings.RAZORPAY_KEY_ID,
            'all_form_data':form_data,
            'payment_success_url':"http://127.0.0.1:8001/my_money/deposite/",
            'payment_failed_url':'http://127.0.0.1:8001/my_money/payment-failed/'
# Public key
        }

        # Render Razorpay checkout page
        return render(request, "razorpay_checkout.html", context)

    # If GET request, redirect to your form page
    return redirect("your_form_page_url")  # replace with your form page URL

