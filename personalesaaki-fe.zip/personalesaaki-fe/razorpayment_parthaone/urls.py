from django.urls import path
from razorpayment.views import *
from .api_view import VerifyPaymentAPIView

app_name = "razorpayment"

urlpatterns = [
    path("razorpay_payment/", razorpay_payment, name="razorpay_payment"),
    path('api/verify-payment/', VerifyPaymentAPIView.as_view(), name='verify_payment'),
]
