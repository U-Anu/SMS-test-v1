from rest_framework.decorators import api_view, permission_classes
from django.views.decorators.csrf import csrf_exempt
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
import razorpay
import uuid
from .serializers import RazorpayPaymentSerializer
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

# Initialize Razorpay client
client = razorpay.Client(
    auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_API_SECRET_KEY)
)
class VerifyPaymentAPIView(APIView):
    """
    Verify Razorpay payment signature
    """
    def post(self, request):
        data = request.data

        razorpay_order_id = data.get("razorpay_order_id")
        razorpay_payment_id = data.get("razorpay_payment_id")
        razorpay_signature = data.get("razorpay_signature")

        # If all three fields are missing or empty → user cancelled
        if not (razorpay_order_id and razorpay_payment_id and razorpay_signature):
            # Optional: check if any field is empty string as well
            if razorpay_order_id in [None, ""] and razorpay_payment_id in [None, ""] and razorpay_signature in [None, ""]:
                return Response({"status": "cancelled", "message": "Payment cancelled by user"})

            # Some fields missing → invalid / tampered request
            return Response({"status": "failed", "error": "Missing parameters"}, status=400)

        try:
            # Verify the payment signature
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': razorpay_payment_id,
                'razorpay_signature': razorpay_signature
            }
            client.utility.verify_payment_signature(params_dict)

            # Payment is valid → save if needed
            return Response({"status": "success"})

        except razorpay.errors.SignatureVerificationError:
            return Response({"status": "failed", "error": "Signature verification failed"}, status=400)
