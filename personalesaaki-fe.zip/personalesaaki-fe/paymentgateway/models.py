from django.db import models
from django.utils import timezone


class Country(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)

    def __str__(self):
        return self.name


class PaymentGateway(models.Model):
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=50, unique=True)
    provider = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class CountryPaymentGatewayMapping(models.Model):
    country = models.ForeignKey(Country, on_delete=models.CASCADE)
    payment_gateway = models.ForeignKey(PaymentGateway, on_delete=models.CASCADE)

    class Meta:
        unique_together = ("country", "payment_gateway")

    def __str__(self):
        return f"{self.country.name} - {self.payment_gateway.name}"


class PaymentDetail(models.Model):
    STATUS_CHOICES = [
        ("SUCCESS", "Successful"),
        ("FAILED", "Failed"),
        ("PENDING", "Pending"),
    ]

    PAYMENT_MODES = [
        ("CARD", "Card"),
        ("UPI", "UPI"),
        ("NET_BANKING", "Net Banking"),
        ("WALLET", "Wallet"),
        ("OTHER", "Other"),
    ]

    payment_order_id = models.CharField(max_length=100, unique=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_mode = models.CharField(max_length=20, choices=PAYMENT_MODES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="PENDING")
    created_time = models.DateTimeField(default=timezone.now)
    payment_gateway = models.ForeignKey(
        PaymentGateway, on_delete=models.CASCADE, related_name="payment_details"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.payment_order_id} - {self.status}"


class FieldType(models.Model):
    name = models.CharField(
        max_length=50, unique=True
    )  # ===> field type  phone number , amount,email

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class FieldName(models.Model):
    field_name = models.CharField(max_length=100)
    field_description = models.TextField(blank=True, null=True)
    field_property = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.field_name


class FieldToPaymentGatewayMapping(models.Model):
    payment_gateway = models.ForeignKey(PaymentGateway, on_delete=models.CASCADE)
    field_name = models.ForeignKey(FieldName, on_delete=models.CASCADE)
    field_type = models.ForeignKey(FieldType, on_delete=models.CASCADE)
    is_required = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("payment_gateway", "field_name")

class PaymentLog(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('SUCCESS', 'Success'),
        ('FAILED', 'Failed'),
    ]

    name = models.CharField(max_length=255, blank=True, null=True)
    email = models.EmailField( blank=True, null=True)
    phone_no = models.CharField(max_length=20, blank=True, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    payment_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="SUCCESS")
    channel_id = models.CharField(max_length=100, blank=True, null=True)  # e.g. "razorpay"
    source = models.CharField(max_length=100, blank=True, null=True)  # e.g. "customer_app", "web"

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Payment  {self.payment_status}"
