from django.urls import path
from paymentgateway.views import *

urlpatterns = [
    path("", home, name="home"),
    # path("payment/<str:status>/", payment_result, name="payment_result"),
    path("payment-result/", payment_result, name="payment_result"),
    # path("process-payment/", process_payment, name="process_payment"),
    # path("add-mapping/", add_field_mapping, name="add_field_mapping"),
]
