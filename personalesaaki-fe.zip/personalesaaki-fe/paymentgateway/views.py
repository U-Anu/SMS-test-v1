from collections import defaultdict
from django.shortcuts import render, redirect
from django.urls import reverse
from .models import (
    Country,
    PaymentGateway,
    CountryPaymentGatewayMapping,
    FieldToPaymentGatewayMapping,
)


from collections import defaultdict
from django.shortcuts import render
from .models import (
    Country,
    PaymentGateway,
    CountryPaymentGatewayMapping,
    FieldToPaymentGatewayMapping,
    FieldName,
    FieldType,
)


def home(request):
    countries = Country.objects.all().order_by("name")

    country_mappings = CountryPaymentGatewayMapping.objects.select_related(
        "country", "payment_gateway"
    ).order_by("country__name", "payment_gateway__name")

    gateway_fields = FieldToPaymentGatewayMapping.objects.select_related(
        "payment_gateway", "field_name", "field_type"
    ).all()

    grouped_fields = defaultdict(list)
    for field in gateway_fields:
        grouped_fields[field.payment_gateway.id].append(field)

    context = {
        "countries": countries,
        "mappings": country_mappings,
        "grouped_fields": grouped_fields,
    }
    return render(request, "payment/home.html", context)


def payment_result(request):
    status = request.GET.get("status", "failed")
    return render(request, "payment/payment_result.html", {"status": status})


# def home(request):
#     countries = Country.objects.all().order_by("name")

#     country_mappings = CountryPaymentGatewayMapping.objects.select_related(
#         "country", "payment_gateway"
#     ).order_by("country__name", "payment_gateway__name")

#     gateway_fields = FieldToPaymentGatewayMapping.objects.select_related(
#         "payment_gateway", "field_name", "field_type"
#     ).all()
#     print("======@@@@", country_mappings, "@@@@=======")
#     print("======@@@@", gateway_fields, "@@@@=======")
#     print("Gateway Fields:")
#     for field in gateway_fields:
#         print(field.payment_gateway.name, field.field_name.field_name, field.field_type.name)

#     context = {
#         "countries": countries,
#         "mappings": country_mappings,
#         "gateway_fields": gateway_fields,
#     }
#     return render(request, "home.html", context)


def process_payment(request):

    if request.method == "POST":
        print("Form submitted as POST")  # Check if POST is triggered
        data = request.POST.dict()
        print("Submitted data:", data)
        return render(request, "home.html")

    if request.method == "POST":
        gateway_code = request.POST.get("gateway_code")
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        amount = request.POST.get("amount")

        # Validate required fields
        if (
            not phone
            or not amount
            or (gateway_code != "mpesa" and (not name or not email))
        ):
            messages.error(request, "Please fill all required fields")
            return redirect("home")

        if gateway_code == "mpesa":

            print(f"Processing MPesa payment: {phone}, {amount}")
        elif gateway_code == "razorpay":

            print(f"Processing Razorpay payment: {name}, {email}, {phone}, {amount}")
        else:
            print(
                f"Processing {gateway_code} payment: {name}, {email}, {phone}, {amount}"
            )

        messages.success(
            request, f"{gateway_code.capitalize()} payment submitted successfully!"
        )
        return redirect("home")

    return redirect("home")
