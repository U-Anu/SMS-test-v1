from django.contrib import admin
from django.contrib import admin
from .models import *


# Register your models here.


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "code")
    search_fields = ("name", "code")
    ordering = ("name",)


@admin.register(PaymentGateway)
class PaymentGatewayAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "code", "provider", "created_at", "updated_at")
    search_fields = ("name", "code", "provider")
    list_filter = ("provider", "created_at")
    ordering = ("name",)


@admin.register(CountryPaymentGatewayMapping)
class CountryPaymentGatewayMappingAdmin(admin.ModelAdmin):
    list_display = ("id", "country", "payment_gateway")
    search_fields = ("country__name", "payment_gateway__name")
    list_filter = ("country", "payment_gateway")
    ordering = ("country", "payment_gateway")


# -------------------------------
# PaymentDetail Admin
# -------------------------------
@admin.register(PaymentDetail)
class PaymentDetailAdmin(admin.ModelAdmin):
    list_display = (
        "payment_order_id",
        "payment_gateway",
        "amount",
        "payment_mode",
        "status",
        "created_time",
    )
    list_filter = ("status", "payment_mode", "payment_gateway")
    search_fields = ("payment_order_id", "payment_gateway__name")
    readonly_fields = ("created_at", "updated_at", "created_time")


# -------------------------------
# FieldType Admin
# -------------------------------
@admin.register(FieldType)
class FieldTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "created_at", "updated_at")
    search_fields = ("name",)
    readonly_fields = ("created_at", "updated_at")


# -------------------------------
# FieldName Admin
# -------------------------------
@admin.register(FieldName)
class FieldNameAdmin(admin.ModelAdmin):
    list_display = (
        "field_name",
        "field_description",
        "field_property",
        "created_at",
        "updated_at",
    )
    search_fields = ("field_name", "field_description")
    readonly_fields = ("created_at", "updated_at")


# -------------------------------
# FieldToPaymentGatewayMapping Admin
# -------------------------------
@admin.register(FieldToPaymentGatewayMapping)
class FieldToPaymentGatewayMappingAdmin(admin.ModelAdmin):
    list_display = (
        "payment_gateway",
        "field_name",
        "field_type",
        "is_required",
        "created_at",
        "updated_at",
    )
    list_filter = ("payment_gateway", "field_type", "is_required")
    search_fields = ("payment_gateway__name", "field_name__field_name")
    readonly_fields = ("created_at", "updated_at")

    autocomplete_fields = ("payment_gateway", "field_name", "field_type")

admin.site.register(PaymentLog)